import { createChannel } from '../node_modules/decentraland-builder-scripts/channel'
import { createInventory } from '../node_modules/decentraland-builder-scripts/inventory'
import Script1 from "../683aa047-8043-40f8-8d31-beb7ab1b138c/src/item"
import Script2 from "../846479b0-75d3-450d-bbd6-7e6b3355a7a2/src/item"
import Script3 from "../68986c60-c95c-41ab-adf0-d0e02f5b5440/src/item"
import Script4 from "../1ab2733f-1782-4521-9eda-6aa8ad684277/src/item"
import Script5 from "../1d45dc17-42d2-4d02-af19-f5528f395b13/src/item"

const _scene = new Entity('_scene')
engine.addEntity(_scene)
const transform = new Transform({
  position: new Vector3(0, 0, 0),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
_scene.addComponentOrReplace(transform)

const entity = new Entity('entity')
engine.addEntity(entity)
entity.setParent(_scene)
const gltfShape = new GLTFShape("models/FloorBaseGrass_01/FloorBaseGrass_01.glb")
gltfShape.withCollisions = true
gltfShape.visible = true
entity.addComponentOrReplace(gltfShape)
const transform2 = new Transform({
  position: new Vector3(8, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity.addComponentOrReplace(transform2)

const entity2 = new Entity('entity2')
engine.addEntity(entity2)
entity2.setParent(_scene)
entity2.addComponentOrReplace(gltfShape)
const transform3 = new Transform({
  position: new Vector3(24, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity2.addComponentOrReplace(transform3)

const entity3 = new Entity('entity3')
engine.addEntity(entity3)
entity3.setParent(_scene)
entity3.addComponentOrReplace(gltfShape)
const transform4 = new Transform({
  position: new Vector3(40, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity3.addComponentOrReplace(transform4)

const entity4 = new Entity('entity4')
engine.addEntity(entity4)
entity4.setParent(_scene)
entity4.addComponentOrReplace(gltfShape)
const transform5 = new Transform({
  position: new Vector3(56, 0, 8),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity4.addComponentOrReplace(transform5)

const entity5 = new Entity('entity5')
engine.addEntity(entity5)
entity5.setParent(_scene)
entity5.addComponentOrReplace(gltfShape)
const transform6 = new Transform({
  position: new Vector3(8, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity5.addComponentOrReplace(transform6)

const entity6 = new Entity('entity6')
engine.addEntity(entity6)
entity6.setParent(_scene)
entity6.addComponentOrReplace(gltfShape)
const transform7 = new Transform({
  position: new Vector3(24, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity6.addComponentOrReplace(transform7)

const entity7 = new Entity('entity7')
engine.addEntity(entity7)
entity7.setParent(_scene)
entity7.addComponentOrReplace(gltfShape)
const transform8 = new Transform({
  position: new Vector3(40, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity7.addComponentOrReplace(transform8)

const entity8 = new Entity('entity8')
engine.addEntity(entity8)
entity8.setParent(_scene)
entity8.addComponentOrReplace(gltfShape)
const transform9 = new Transform({
  position: new Vector3(56, 0, 24),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity8.addComponentOrReplace(transform9)

const entity9 = new Entity('entity9')
engine.addEntity(entity9)
entity9.setParent(_scene)
entity9.addComponentOrReplace(gltfShape)
const transform10 = new Transform({
  position: new Vector3(8, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity9.addComponentOrReplace(transform10)

const entity10 = new Entity('entity10')
engine.addEntity(entity10)
entity10.setParent(_scene)
entity10.addComponentOrReplace(gltfShape)
const transform11 = new Transform({
  position: new Vector3(24, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity10.addComponentOrReplace(transform11)

const entity11 = new Entity('entity11')
engine.addEntity(entity11)
entity11.setParent(_scene)
entity11.addComponentOrReplace(gltfShape)
const transform12 = new Transform({
  position: new Vector3(40, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity11.addComponentOrReplace(transform12)

const entity12 = new Entity('entity12')
engine.addEntity(entity12)
entity12.setParent(_scene)
entity12.addComponentOrReplace(gltfShape)
const transform13 = new Transform({
  position: new Vector3(56, 0, 40),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity12.addComponentOrReplace(transform13)

const entity13 = new Entity('entity13')
engine.addEntity(entity13)
entity13.setParent(_scene)
entity13.addComponentOrReplace(gltfShape)
const transform14 = new Transform({
  position: new Vector3(8, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity13.addComponentOrReplace(transform14)

const entity14 = new Entity('entity14')
engine.addEntity(entity14)
entity14.setParent(_scene)
entity14.addComponentOrReplace(gltfShape)
const transform15 = new Transform({
  position: new Vector3(24, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity14.addComponentOrReplace(transform15)

const entity15 = new Entity('entity15')
engine.addEntity(entity15)
entity15.setParent(_scene)
entity15.addComponentOrReplace(gltfShape)
const transform16 = new Transform({
  position: new Vector3(40, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity15.addComponentOrReplace(transform16)

const entity16 = new Entity('entity16')
engine.addEntity(entity16)
entity16.setParent(_scene)
entity16.addComponentOrReplace(gltfShape)
const transform17 = new Transform({
  position: new Vector3(56, 0, 56),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity16.addComponentOrReplace(transform17)

const entity17 = new Entity('entity17')
engine.addEntity(entity17)
entity17.setParent(_scene)
entity17.addComponentOrReplace(gltfShape)
const transform18 = new Transform({
  position: new Vector3(8, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity17.addComponentOrReplace(transform18)

const entity18 = new Entity('entity18')
engine.addEntity(entity18)
entity18.setParent(_scene)
entity18.addComponentOrReplace(gltfShape)
const transform19 = new Transform({
  position: new Vector3(24, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity18.addComponentOrReplace(transform19)

const entity19 = new Entity('entity19')
engine.addEntity(entity19)
entity19.setParent(_scene)
entity19.addComponentOrReplace(gltfShape)
const transform20 = new Transform({
  position: new Vector3(40, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity19.addComponentOrReplace(transform20)

const entity20 = new Entity('entity20')
engine.addEntity(entity20)
entity20.setParent(_scene)
entity20.addComponentOrReplace(gltfShape)
const transform21 = new Transform({
  position: new Vector3(56, 0, 72),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity20.addComponentOrReplace(transform21)

const entity21 = new Entity('entity21')
engine.addEntity(entity21)
entity21.setParent(_scene)
entity21.addComponentOrReplace(gltfShape)
const transform22 = new Transform({
  position: new Vector3(8, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity21.addComponentOrReplace(transform22)

const entity22 = new Entity('entity22')
engine.addEntity(entity22)
entity22.setParent(_scene)
entity22.addComponentOrReplace(gltfShape)
const transform23 = new Transform({
  position: new Vector3(24, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity22.addComponentOrReplace(transform23)

const entity23 = new Entity('entity23')
engine.addEntity(entity23)
entity23.setParent(_scene)
entity23.addComponentOrReplace(gltfShape)
const transform24 = new Transform({
  position: new Vector3(40, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity23.addComponentOrReplace(transform24)

const entity24 = new Entity('entity24')
engine.addEntity(entity24)
entity24.setParent(_scene)
entity24.addComponentOrReplace(gltfShape)
const transform25 = new Transform({
  position: new Vector3(56, 0, 88),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity24.addComponentOrReplace(transform25)

const entity25 = new Entity('entity25')
engine.addEntity(entity25)
entity25.setParent(_scene)
entity25.addComponentOrReplace(gltfShape)
const transform26 = new Transform({
  position: new Vector3(8, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity25.addComponentOrReplace(transform26)

const entity26 = new Entity('entity26')
engine.addEntity(entity26)
entity26.setParent(_scene)
entity26.addComponentOrReplace(gltfShape)
const transform27 = new Transform({
  position: new Vector3(24, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity26.addComponentOrReplace(transform27)

const entity27 = new Entity('entity27')
engine.addEntity(entity27)
entity27.setParent(_scene)
entity27.addComponentOrReplace(gltfShape)
const transform28 = new Transform({
  position: new Vector3(40, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity27.addComponentOrReplace(transform28)

const entity28 = new Entity('entity28')
engine.addEntity(entity28)
entity28.setParent(_scene)
entity28.addComponentOrReplace(gltfShape)
const transform29 = new Transform({
  position: new Vector3(56, 0, 104),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity28.addComponentOrReplace(transform29)

const entity29 = new Entity('entity29')
engine.addEntity(entity29)
entity29.setParent(_scene)
entity29.addComponentOrReplace(gltfShape)
const transform30 = new Transform({
  position: new Vector3(8, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity29.addComponentOrReplace(transform30)

const entity30 = new Entity('entity30')
engine.addEntity(entity30)
entity30.setParent(_scene)
entity30.addComponentOrReplace(gltfShape)
const transform31 = new Transform({
  position: new Vector3(24, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity30.addComponentOrReplace(transform31)

const entity31 = new Entity('entity31')
engine.addEntity(entity31)
entity31.setParent(_scene)
entity31.addComponentOrReplace(gltfShape)
const transform32 = new Transform({
  position: new Vector3(40, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity31.addComponentOrReplace(transform32)

const entity32 = new Entity('entity32')
engine.addEntity(entity32)
entity32.setParent(_scene)
entity32.addComponentOrReplace(gltfShape)
const transform33 = new Transform({
  position: new Vector3(56, 0, 120),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
entity32.addComponentOrReplace(transform33)

const snowfloor = new Entity('snowfloor')
engine.addEntity(snowfloor)
snowfloor.setParent(_scene)
const transform34 = new Transform({
  position: new Vector3(56.61121368408203, 0.10405158996582031, 7.38093376159668),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor.addComponentOrReplace(transform34)
const gltfShape2 = new GLTFShape("models/SnowFloor.glb")
gltfShape2.withCollisions = true
gltfShape2.visible = true
snowfloor.addComponentOrReplace(gltfShape2)

const snowfloor2 = new Entity('snowfloor2')
engine.addEntity(snowfloor2)
snowfloor2.setParent(_scene)
snowfloor2.addComponentOrReplace(gltfShape2)
const transform35 = new Transform({
  position: new Vector3(41.838809967041016, 0.10405158996582031, 7.382349491119385),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor2.addComponentOrReplace(transform35)

const snowfloor5 = new Entity('snowfloor5')
engine.addEntity(snowfloor5)
snowfloor5.setParent(_scene)
snowfloor5.addComponentOrReplace(gltfShape2)
const transform36 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 7.394778251647949),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 1)
})
snowfloor5.addComponentOrReplace(transform36)

const snowfloor3 = new Entity('snowfloor3')
engine.addEntity(snowfloor3)
snowfloor3.setParent(_scene)
snowfloor3.addComponentOrReplace(gltfShape2)
const transform37 = new Transform({
  position: new Vector3(27.08966827392578, 0.10405158996582031, 7.382349967956543),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor3.addComponentOrReplace(transform37)

const snowfloor4 = new Entity('snowfloor4')
engine.addEntity(snowfloor4)
snowfloor4.setParent(_scene)
snowfloor4.addComponentOrReplace(gltfShape2)
const transform38 = new Transform({
  position: new Vector3(12.383049011230469, 0.10405158996582031, 7.382349967956543),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor4.addComponentOrReplace(transform38)

const snowfloor6 = new Entity('snowfloor6')
engine.addEntity(snowfloor6)
snowfloor6.setParent(_scene)
snowfloor6.addComponentOrReplace(gltfShape2)
const transform39 = new Transform({
  position: new Vector3(56.61121368408203, 0.10405158996582031, 36.86012268066406),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor6.addComponentOrReplace(transform39)

const snowfloor7 = new Entity('snowfloor7')
engine.addEntity(snowfloor7)
snowfloor7.setParent(_scene)
snowfloor7.addComponentOrReplace(gltfShape2)
const transform40 = new Transform({
  position: new Vector3(56.61121368408203, 0.10405158996582031, 22.13336944580078),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor7.addComponentOrReplace(transform40)

const snowfloor8 = new Entity('snowfloor8')
engine.addEntity(snowfloor8)
snowfloor8.setParent(_scene)
snowfloor8.addComponentOrReplace(gltfShape2)
const transform41 = new Transform({
  position: new Vector3(56.53892517089844, 0.10405158996582031, 51.622859954833984),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor8.addComponentOrReplace(transform41)

const snowfloor9 = new Entity('snowfloor9')
engine.addEntity(snowfloor9)
snowfloor9.setParent(_scene)
snowfloor9.addComponentOrReplace(gltfShape2)
const transform42 = new Transform({
  position: new Vector3(56.55533218383789, 0.10405158996582031, 66.37276458740234),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor9.addComponentOrReplace(transform42)

const snowfloor10 = new Entity('snowfloor10')
engine.addEntity(snowfloor10)
snowfloor10.setParent(_scene)
snowfloor10.addComponentOrReplace(gltfShape2)
const transform43 = new Transform({
  position: new Vector3(56.49717712402344, 0.10405158996582031, 81.10186004638672),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor10.addComponentOrReplace(transform43)

const snowfloor11 = new Entity('snowfloor11')
engine.addEntity(snowfloor11)
snowfloor11.setParent(_scene)
snowfloor11.addComponentOrReplace(gltfShape2)
const transform44 = new Transform({
  position: new Vector3(56.532745361328125, 0.10405158996582031, 95.87991333007812),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor11.addComponentOrReplace(transform44)

const snowfloor12 = new Entity('snowfloor12')
engine.addEntity(snowfloor12)
snowfloor12.setParent(_scene)
snowfloor12.addComponentOrReplace(gltfShape2)
const transform45 = new Transform({
  position: new Vector3(56.4785041809082, 0.10405158996582031, 110.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor12.addComponentOrReplace(transform45)

const snowfloor13 = new Entity('snowfloor13')
engine.addEntity(snowfloor13)
snowfloor13.setParent(_scene)
snowfloor13.addComponentOrReplace(gltfShape2)
const transform46 = new Transform({
  position: new Vector3(56.58711242675781, 0.10405158996582031, 122.76683044433594),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.0019758939743042, 1.3426116704940796, 0.6618430614471436)
})
snowfloor13.addComponentOrReplace(transform46)

const snowfloor14 = new Entity('snowfloor14')
engine.addEntity(snowfloor14)
snowfloor14.setParent(_scene)
snowfloor14.addComponentOrReplace(gltfShape2)
const transform47 = new Transform({
  position: new Vector3(41.838809967041016, 0.10405158996582031, 22.141273498535156),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor14.addComponentOrReplace(transform47)

const snowfloor15 = new Entity('snowfloor15')
engine.addEntity(snowfloor15)
snowfloor15.setParent(_scene)
snowfloor15.addComponentOrReplace(gltfShape2)
const transform48 = new Transform({
  position: new Vector3(41.838809967041016, 0.10405158996582031, 36.88456344604492),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor15.addComponentOrReplace(transform48)

const snowfloor16 = new Entity('snowfloor16')
engine.addEntity(snowfloor16)
snowfloor16.setParent(_scene)
snowfloor16.addComponentOrReplace(gltfShape2)
const transform49 = new Transform({
  position: new Vector3(27.08966827392578, 0.10405158996582031, 22.07126235961914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor16.addComponentOrReplace(transform49)

const snowfloor17 = new Entity('snowfloor17')
engine.addEntity(snowfloor17)
snowfloor17.setParent(_scene)
snowfloor17.addComponentOrReplace(gltfShape2)
const transform50 = new Transform({
  position: new Vector3(12.383049011230469, 0.10405158996582031, 22.104724884033203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor17.addComponentOrReplace(transform50)

const snowfloor18 = new Entity('snowfloor18')
engine.addEntity(snowfloor18)
snowfloor18.setParent(_scene)
snowfloor18.addComponentOrReplace(gltfShape2)
const transform51 = new Transform({
  position: new Vector3(12.383049011230469, 0.10405158996582031, 36.675994873046875),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor18.addComponentOrReplace(transform51)

const snowfloor19 = new Entity('snowfloor19')
engine.addEntity(snowfloor19)
snowfloor19.setParent(_scene)
snowfloor19.addComponentOrReplace(gltfShape2)
const transform52 = new Transform({
  position: new Vector3(12.383049011230469, 0.10405158996582031, 51.43519592285156),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor19.addComponentOrReplace(transform52)

const snowfloor20 = new Entity('snowfloor20')
engine.addEntity(snowfloor20)
snowfloor20.setParent(_scene)
snowfloor20.addComponentOrReplace(gltfShape2)
const transform53 = new Transform({
  position: new Vector3(12.383049011230469, 0.10405158996582031, 66.19783782958984),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor20.addComponentOrReplace(transform53)

const snowfloor21 = new Entity('snowfloor21')
engine.addEntity(snowfloor21)
snowfloor21.setParent(_scene)
snowfloor21.addComponentOrReplace(gltfShape2)
const transform54 = new Transform({
  position: new Vector3(12.383049011230469, 0.10405158996582031, 80.93868255615234),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor21.addComponentOrReplace(transform54)

const snowfloor22 = new Entity('snowfloor22')
engine.addEntity(snowfloor22)
snowfloor22.setParent(_scene)
snowfloor22.addComponentOrReplace(gltfShape2)
const transform55 = new Transform({
  position: new Vector3(12.383049011230469, 0.10405158996582031, 110.38003540039062),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor22.addComponentOrReplace(transform55)

const snowfloor23 = new Entity('snowfloor23')
engine.addEntity(snowfloor23)
snowfloor23.setParent(_scene)
snowfloor23.addComponentOrReplace(gltfShape2)
const transform56 = new Transform({
  position: new Vector3(12.383049011230469, 0.10405158996582031, 95.70047760009766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor23.addComponentOrReplace(transform56)

const snowfloor24 = new Entity('snowfloor24')
engine.addEntity(snowfloor24)
snowfloor24.setParent(_scene)
snowfloor24.addComponentOrReplace(gltfShape2)
const transform57 = new Transform({
  position: new Vector3(27.019655227661133, 0.10405158996582031, 66.19783782958984),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor24.addComponentOrReplace(transform57)

const snowfloor25 = new Entity('snowfloor25')
engine.addEntity(snowfloor25)
snowfloor25.setParent(_scene)
snowfloor25.addComponentOrReplace(gltfShape2)
const transform58 = new Transform({
  position: new Vector3(27.019655227661133, 0.10405158996582031, 80.89913940429688),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor25.addComponentOrReplace(transform58)

const snowfloor27 = new Entity('snowfloor27')
engine.addEntity(snowfloor27)
snowfloor27.setParent(_scene)
snowfloor27.addComponentOrReplace(gltfShape2)
const transform59 = new Transform({
  position: new Vector3(41.7830924987793, 0.10405158996582031, 80.89913940429688),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor27.addComponentOrReplace(transform59)

const snowfloor28 = new Entity('snowfloor28')
engine.addEntity(snowfloor28)
snowfloor28.setParent(_scene)
snowfloor28.addComponentOrReplace(gltfShape2)
const transform60 = new Transform({
  position: new Vector3(41.7830924987793, 0.10405158996582031, 66.19633483886719),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor28.addComponentOrReplace(transform60)

const snowfloor29 = new Entity('snowfloor29')
engine.addEntity(snowfloor29)
snowfloor29.setParent(_scene)
snowfloor29.addComponentOrReplace(gltfShape2)
const transform61 = new Transform({
  position: new Vector3(41.7830924987793, 0.10405158996582031, 51.47275924682617),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor29.addComponentOrReplace(transform61)

const snowfloor30 = new Entity('snowfloor30')
engine.addEntity(snowfloor30)
snowfloor30.setParent(_scene)
snowfloor30.addComponentOrReplace(gltfShape2)
const transform62 = new Transform({
  position: new Vector3(27.06092643737793, 0.10405158996582031, 51.47275924682617),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor30.addComponentOrReplace(transform62)

const snowfloor31 = new Entity('snowfloor31')
engine.addEntity(snowfloor31)
snowfloor31.setParent(_scene)
snowfloor31.addComponentOrReplace(gltfShape2)
const transform63 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 22.166584014892578),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 1)
})
snowfloor31.addComponentOrReplace(transform63)

const snowfloor32 = new Entity('snowfloor32')
engine.addEntity(snowfloor32)
snowfloor32.setParent(_scene)
snowfloor32.addComponentOrReplace(gltfShape2)
const transform64 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 81.24430084228516),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 1)
})
snowfloor32.addComponentOrReplace(transform64)

const snowfloor33 = new Entity('snowfloor33')
engine.addEntity(snowfloor33)
snowfloor33.setParent(_scene)
snowfloor33.addComponentOrReplace(gltfShape2)
const transform65 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 36.938568115234375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 1)
})
snowfloor33.addComponentOrReplace(transform65)

const snowfloor34 = new Entity('snowfloor34')
engine.addEntity(snowfloor34)
snowfloor34.setParent(_scene)
snowfloor34.addComponentOrReplace(gltfShape2)
const transform66 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 51.71396255493164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 1)
})
snowfloor34.addComponentOrReplace(transform66)

const snowfloor35 = new Entity('snowfloor35')
engine.addEntity(snowfloor35)
snowfloor35.setParent(_scene)
snowfloor35.addComponentOrReplace(gltfShape2)
const transform67 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 66.4776382446289),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 1)
})
snowfloor35.addComponentOrReplace(transform67)

const snowfloor36 = new Entity('snowfloor36')
engine.addEntity(snowfloor36)
snowfloor36.setParent(_scene)
snowfloor36.addComponentOrReplace(gltfShape2)
const transform68 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 96.0114517211914),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 1)
})
snowfloor36.addComponentOrReplace(transform68)

const snowfloor37 = new Entity('snowfloor37')
engine.addEntity(snowfloor37)
snowfloor37.setParent(_scene)
snowfloor37.addComponentOrReplace(gltfShape2)
const transform69 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 110.70256042480469),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 1)
})
snowfloor37.addComponentOrReplace(transform69)

const snowfloor38 = new Entity('snowfloor38')
engine.addEntity(snowfloor38)
snowfloor38.setParent(_scene)
snowfloor38.addComponentOrReplace(gltfShape2)
const transform70 = new Transform({
  position: new Vector3(41.85697937011719, 0.10405158996582031, 120.36540985107422),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor38.addComponentOrReplace(transform70)

const snowfloor39 = new Entity('snowfloor39')
engine.addEntity(snowfloor39)
snowfloor39.setParent(_scene)
snowfloor39.addComponentOrReplace(gltfShape2)
const transform71 = new Transform({
  position: new Vector3(27.099079132080078, 0.10405158996582031, 120.36540985107422),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor39.addComponentOrReplace(transform71)

const snowfloor40 = new Entity('snowfloor40')
engine.addEntity(snowfloor40)
snowfloor40.setParent(_scene)
snowfloor40.addComponentOrReplace(gltfShape2)
const transform72 = new Transform({
  position: new Vector3(12.35910701751709, 0.10405158996582031, 122.68721771240234),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 0.6818830966949463)
})
snowfloor40.addComponentOrReplace(transform72)

const snowfloor41 = new Entity('snowfloor41')
engine.addEntity(snowfloor41)
snowfloor41.setParent(_scene)
snowfloor41.addComponentOrReplace(gltfShape2)
const transform73 = new Transform({
  position: new Vector3(2.580049514770508, 0.10405158996582031, 122.92827606201172),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.3454296886920929, 1, 0.6555037498474121)
})
snowfloor41.addComponentOrReplace(transform73)

const snowfloor26 = new Entity('snowfloor26')
engine.addEntity(snowfloor26)
snowfloor26.setParent(_scene)
snowfloor26.addComponentOrReplace(gltfShape2)
const transform74 = new Transform({
  position: new Vector3(27.019655227661133, 0.10405158996582031, 107.86277770996094),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 0.7120177745819092)
})
snowfloor26.addComponentOrReplace(transform74)

const snowfloor42 = new Entity('snowfloor42')
engine.addEntity(snowfloor42)
snowfloor42.setParent(_scene)
snowfloor42.addComponentOrReplace(gltfShape2)
const transform75 = new Transform({
  position: new Vector3(41.73297882080078, 0.10405158996582031, 105.64934539794922),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor42.addComponentOrReplace(transform75)

const snowfloor43 = new Entity('snowfloor43')
engine.addEntity(snowfloor43)
snowfloor43.setParent(_scene)
snowfloor43.addComponentOrReplace(gltfShape2)
const transform76 = new Transform({
  position: new Vector3(27.019655227661133, 0.10405158996582031, 95.47859954833984),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor43.addComponentOrReplace(transform76)

const snowfloor44 = new Entity('snowfloor44')
engine.addEntity(snowfloor44)
snowfloor44.setParent(_scene)
snowfloor44.addComponentOrReplace(gltfShape2)
const transform77 = new Transform({
  position: new Vector3(27.08966827392578, 0.10405158996582031, 36.72608947753906),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowfloor44.addComponentOrReplace(transform77)

const snowfloor45 = new Entity('snowfloor45')
engine.addEntity(snowfloor45)
snowfloor45.setParent(_scene)
snowfloor45.addComponentOrReplace(gltfShape2)
const transform78 = new Transform({
  position: new Vector3(41.791168212890625, 0.10405158996582031, 93.56720733642578),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 0.7209769487380981)
})
snowfloor45.addComponentOrReplace(transform78)

const present = new Entity('present')
engine.addEntity(present)
present.setParent(_scene)
const transform79 = new Transform({
  position: new Vector3(57.33502960205078, 5.347115993499756, 9.757798194885254),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.5510940551757812, 0.5510940551757812, 0.5510940551757812)
})
present.addComponentOrReplace(transform79)
const gltfShape3 = new GLTFShape("models/present.glb")
gltfShape3.withCollisions = true
gltfShape3.visible = true
present.addComponentOrReplace(gltfShape3)

const snowypine = new Entity('snowypine')
engine.addEntity(snowypine)
snowypine.setParent(_scene)
const transform80 = new Transform({
  position: new Vector3(8.985573768615723, 0, 31.087207794189453),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine.addComponentOrReplace(transform80)
const gltfShape4 = new GLTFShape("models/SnowyPine.glb")
gltfShape4.withCollisions = true
gltfShape4.visible = true
snowypine.addComponentOrReplace(gltfShape4)

const snowypine2 = new Entity('snowypine2')
engine.addEntity(snowypine2)
snowypine2.setParent(_scene)
snowypine2.addComponentOrReplace(gltfShape4)
const transform81 = new Transform({
  position: new Vector3(10.957037925720215, 0, 27.81642723083496),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine2.addComponentOrReplace(transform81)

const snowypine3 = new Entity('snowypine3')
engine.addEntity(snowypine3)
snowypine3.setParent(_scene)
snowypine3.addComponentOrReplace(gltfShape4)
const transform82 = new Transform({
  position: new Vector3(5.894940376281738, 0, 16.51708984375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine3.addComponentOrReplace(transform82)

const snowypine4 = new Entity('snowypine4')
engine.addEntity(snowypine4)
snowypine4.setParent(_scene)
snowypine4.addComponentOrReplace(gltfShape4)
const transform83 = new Transform({
  position: new Vector3(3.6845669746398926, 0, 19.53993797302246),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine4.addComponentOrReplace(transform83)

const snowypine5 = new Entity('snowypine5')
engine.addEntity(snowypine5)
snowypine5.setParent(_scene)
snowypine5.addComponentOrReplace(gltfShape4)
const transform84 = new Transform({
  position: new Vector3(2.955641746520996, 0, 12.447754859924316),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine5.addComponentOrReplace(transform84)

const snowypine6 = new Entity('snowypine6')
engine.addEntity(snowypine6)
snowypine6.setParent(_scene)
snowypine6.addComponentOrReplace(gltfShape4)
const transform85 = new Transform({
  position: new Vector3(13.775768280029297, 0, 10.666654586791992),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine6.addComponentOrReplace(transform85)

const snowypine7 = new Entity('snowypine7')
engine.addEntity(snowypine7)
snowypine7.setParent(_scene)
snowypine7.addComponentOrReplace(gltfShape4)
const transform86 = new Transform({
  position: new Vector3(10.578758239746094, 0, 11.505017280578613),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine7.addComponentOrReplace(transform86)

const snowypine8 = new Entity('snowypine8')
engine.addEntity(snowypine8)
snowypine8.setParent(_scene)
snowypine8.addComponentOrReplace(gltfShape4)
const transform87 = new Transform({
  position: new Vector3(4.46943473815918, 0, 4.513409614562988),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine8.addComponentOrReplace(transform87)

const snowypine9 = new Entity('snowypine9')
engine.addEntity(snowypine9)
snowypine9.setParent(_scene)
snowypine9.addComponentOrReplace(gltfShape4)
const transform88 = new Transform({
  position: new Vector3(12.5834321975708, 0, 3.445246696472168),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine9.addComponentOrReplace(transform88)

const snowypine10 = new Entity('snowypine10')
engine.addEntity(snowypine10)
snowypine10.setParent(_scene)
snowypine10.addComponentOrReplace(gltfShape4)
const transform89 = new Transform({
  position: new Vector3(11.280795097351074, 0, 40.43254470825195),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine10.addComponentOrReplace(transform89)

const snowypine11 = new Entity('snowypine11')
engine.addEntity(snowypine11)
snowypine11.setParent(_scene)
snowypine11.addComponentOrReplace(gltfShape4)
const transform90 = new Transform({
  position: new Vector3(11.455962181091309, 0, 43.41621398925781),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine11.addComponentOrReplace(transform90)

const snowypine12 = new Entity('snowypine12')
engine.addEntity(snowypine12)
snowypine12.setParent(_scene)
snowypine12.addComponentOrReplace(gltfShape4)
const transform91 = new Transform({
  position: new Vector3(8.216782569885254, 0, 42.042388916015625),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine12.addComponentOrReplace(transform91)

const snowypine13 = new Entity('snowypine13')
engine.addEntity(snowypine13)
snowypine13.setParent(_scene)
snowypine13.addComponentOrReplace(gltfShape4)
const transform92 = new Transform({
  position: new Vector3(2.161648750305176, 0, 35.18842315673828),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine13.addComponentOrReplace(transform92)

const snowypine14 = new Entity('snowypine14')
engine.addEntity(snowypine14)
snowypine14.setParent(_scene)
snowypine14.addComponentOrReplace(gltfShape4)
const transform93 = new Transform({
  position: new Vector3(2.161648750305176, 0, 49.39578628540039),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine14.addComponentOrReplace(transform93)

const iceledge = new Entity('iceledge')
engine.addEntity(iceledge)
iceledge.setParent(_scene)
const transform94 = new Transform({
  position: new Vector3(56.08367156982422, 0, 9.665212631225586),
  rotation: new Quaternion(-1.8898808536724817e-16, -0.3686458170413971, 4.3946009498085914e-8, 0.9295700192451477),
  scale: new Vector3(2.3527183532714844, 2.3527183532714844, 2.3527183532714844)
})
iceledge.addComponentOrReplace(transform94)
const gltfShape5 = new GLTFShape("models/IceLedge.glb")
gltfShape5.withCollisions = true
gltfShape5.visible = true
iceledge.addComponentOrReplace(gltfShape5)

const snowpile = new Entity('snowpile')
engine.addEntity(snowpile)
snowpile.setParent(_scene)
const transform95 = new Transform({
  position: new Vector3(53.42354965209961, 0, 11.906669616699219),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
snowpile.addComponentOrReplace(transform95)
const gltfShape6 = new GLTFShape("models/snowpile.glb")
gltfShape6.withCollisions = true
gltfShape6.visible = true
snowpile.addComponentOrReplace(gltfShape6)

const cyanMagicStone = new Entity('cyanMagicStone')
engine.addEntity(cyanMagicStone)
cyanMagicStone.setParent(_scene)
const transform96 = new Transform({
  position: new Vector3(40.02092361450195, 4.2215895652771, 22.5),
  rotation: new Quaternion(0.5682466626167297, -0.08636236935853958, 0.7834341526031494, -0.23636461794376373),
  scale: new Vector3(1, 1, 1)
})
cyanMagicStone.addComponentOrReplace(transform96)
const gltfShape7 = new GLTFShape("models/Crystal_03/Crystal_03.glb")
gltfShape7.withCollisions = true
gltfShape7.visible = true
cyanMagicStone.addComponentOrReplace(gltfShape7)

const cyanMagicStone2 = new Entity('cyanMagicStone2')
engine.addEntity(cyanMagicStone2)
cyanMagicStone2.setParent(_scene)
cyanMagicStone2.addComponentOrReplace(gltfShape7)
const transform97 = new Transform({
  position: new Vector3(40.021907806396484, 4.168591022491455, 23.070524215698242),
  rotation: new Quaternion(0.029232772067189217, -0.19367054104804993, -0.9652310013771057, 0.17310787737369537),
  scale: new Vector3(0.4427502751350403, 0.6892004013061523, 0.8184441924095154)
})
cyanMagicStone2.addComponentOrReplace(transform97)

const cyanMagicStone3 = new Entity('cyanMagicStone3')
engine.addEntity(cyanMagicStone3)
cyanMagicStone3.setParent(_scene)
cyanMagicStone3.addComponentOrReplace(gltfShape7)
const transform98 = new Transform({
  position: new Vector3(38.74463653564453, 3.5460877418518066, 16.837949752807617),
  rotation: new Quaternion(0.620098352432251, 0.23314914107322693, 0.7482175827026367, 0.03591638058423996),
  scale: new Vector3(1, 1, 1)
})
cyanMagicStone3.addComponentOrReplace(transform98)

const cyanMagicStone4 = new Entity('cyanMagicStone4')
engine.addEntity(cyanMagicStone4)
cyanMagicStone4.setParent(_scene)
cyanMagicStone4.addComponentOrReplace(gltfShape7)
const transform99 = new Transform({
  position: new Vector3(40.02092361450195, 4.609975337982178, 18.724334716796875),
  rotation: new Quaternion(0.6151092052459717, 0.24601049721240997, 0.7488032579421997, 0.02032889798283577),
  scale: new Vector3(1, 1, 1)
})
cyanMagicStone4.addComponentOrReplace(transform99)

const cyanMagicStone5 = new Entity('cyanMagicStone5')
engine.addEntity(cyanMagicStone5)
cyanMagicStone5.setParent(_scene)
cyanMagicStone5.addComponentOrReplace(gltfShape7)
const transform100 = new Transform({
  position: new Vector3(42.49100112915039, 2.075737714767456, 29.105058670043945),
  rotation: new Quaternion(-0.018337983638048172, 0.6067041158676147, -0.13468967378139496, -0.7832193374633789),
  scale: new Vector3(2.1473922729492188, 1.5721611976623535, 2.408736228942871)
})
cyanMagicStone5.addComponentOrReplace(transform100)

const cyanMagicStone6 = new Entity('cyanMagicStone6')
engine.addEntity(cyanMagicStone6)
cyanMagicStone6.setParent(_scene)
cyanMagicStone6.addComponentOrReplace(gltfShape7)
const transform101 = new Transform({
  position: new Vector3(36.233394622802734, 0, 20.23919677734375),
  rotation: new Quaternion(-0.05759213864803314, -0.732734739780426, -0.41293758153915405, 0.537834107875824),
  scale: new Vector3(1.8952772617340088, 1.3253177404403687, 2.1645965576171875)
})
cyanMagicStone6.addComponentOrReplace(transform101)

const cyanMagicStone7 = new Entity('cyanMagicStone7')
engine.addEntity(cyanMagicStone7)
cyanMagicStone7.setParent(_scene)
cyanMagicStone7.addComponentOrReplace(gltfShape7)
const transform102 = new Transform({
  position: new Vector3(38.49349594116211, 4.0918869972229, 18.30820083618164),
  rotation: new Quaternion(0.749194860458374, 0.3011370301246643, 0.5584934949874878, -0.19002293050289154),
  scale: new Vector3(0.8224449157714844, 0.8224449157714844, 0.8224449157714844)
})
cyanMagicStone7.addComponentOrReplace(transform102)

const cyanMagicStone8 = new Entity('cyanMagicStone8')
engine.addEntity(cyanMagicStone8)
cyanMagicStone8.setParent(_scene)
cyanMagicStone8.addComponentOrReplace(gltfShape7)
const transform103 = new Transform({
  position: new Vector3(36.6302490234375, 0.047814369201660156, 26.372060775756836),
  rotation: new Quaternion(-0.39268532395362854, -0.8255324959754944, 0.16097746789455414, 0.3719955384731293),
  scale: new Vector3(1.8952772617340088, 1.3253177404403687, 2.1645965576171875)
})
cyanMagicStone8.addComponentOrReplace(transform103)

const cyanMagicStone9 = new Entity('cyanMagicStone9')
engine.addEntity(cyanMagicStone9)
cyanMagicStone9.setParent(_scene)
cyanMagicStone9.addComponentOrReplace(gltfShape7)
const transform104 = new Transform({
  position: new Vector3(35.861541748046875, 0.33294105529785156, 24.17561912536621),
  rotation: new Quaternion(-0.524003267288208, -0.8156593441963196, 0.11993011087179184, 0.2138623595237732),
  scale: new Vector3(1.2193635702133179, 1.5531065464019775, 1.1362390518188477)
})
cyanMagicStone9.addComponentOrReplace(transform104)

const cyanMagicStone10 = new Entity('cyanMagicStone10')
engine.addEntity(cyanMagicStone10)
cyanMagicStone10.setParent(_scene)
cyanMagicStone10.addComponentOrReplace(gltfShape7)
const transform105 = new Transform({
  position: new Vector3(36.13617706298828, 0.749997615814209, 16.830856323242188),
  rotation: new Quaternion(-0.7445956468582153, -0.5303611159324646, -0.04025110602378845, 0.4033289849758148),
  scale: new Vector3(2.6385273933410645, 1.1312456130981445, 2.8057000637054443)
})
cyanMagicStone10.addComponentOrReplace(transform105)

const cyanMagicStone11 = new Entity('cyanMagicStone11')
engine.addEntity(cyanMagicStone11)
cyanMagicStone11.setParent(_scene)
cyanMagicStone11.addComponentOrReplace(gltfShape7)
const transform106 = new Transform({
  position: new Vector3(36.2985954284668, 0.2855558395385742, 18.190065383911133),
  rotation: new Quaternion(-0.02378428541123867, 0.6022826433181763, 0.45275112986564636, -0.6570436954498291),
  scale: new Vector3(1, 1, 1)
})
cyanMagicStone11.addComponentOrReplace(transform106)

const cyanMagicStone12 = new Entity('cyanMagicStone12')
engine.addEntity(cyanMagicStone12)
cyanMagicStone12.setParent(_scene)
cyanMagicStone12.addComponentOrReplace(gltfShape7)
const transform107 = new Transform({
  position: new Vector3(40.02092361450195, 3.8673295974731445, 27.285348892211914),
  rotation: new Quaternion(0.5682466626167297, -0.08636236935853958, 0.7834341526031494, -0.23636461794376373),
  scale: new Vector3(1, 1, 1)
})
cyanMagicStone12.addComponentOrReplace(transform107)

const cyanMagicStone13 = new Entity('cyanMagicStone13')
engine.addEntity(cyanMagicStone13)
cyanMagicStone13.setParent(_scene)
cyanMagicStone13.addComponentOrReplace(gltfShape7)
const transform108 = new Transform({
  position: new Vector3(42.4450798034668, 3.8673295974731445, 31.15604019165039),
  rotation: new Quaternion(0.5880794525146484, -0.01177037600427866, 0.7880920171737671, -0.18147994577884674),
  scale: new Vector3(0.8446693420410156, 0.8446693420410156, 0.8446693420410156)
})
cyanMagicStone13.addComponentOrReplace(transform108)

const cyanMagicStone14 = new Entity('cyanMagicStone14')
engine.addEntity(cyanMagicStone14)
cyanMagicStone14.setParent(_scene)
cyanMagicStone14.addComponentOrReplace(gltfShape7)
const transform109 = new Transform({
  position: new Vector3(37.62051773071289, 0.047814369201660156, 14.466599464416504),
  rotation: new Quaternion(0.3910076916217804, 0.845818817615509, 0.1650104522705078, 0.32322609424591064),
  scale: new Vector3(1.8952772617340088, 1.3253177404403687, 2.1645965576171875)
})
cyanMagicStone14.addComponentOrReplace(transform109)

const cyanMagicStone15 = new Entity('cyanMagicStone15')
engine.addEntity(cyanMagicStone15)
cyanMagicStone15.setParent(_scene)
cyanMagicStone15.addComponentOrReplace(gltfShape7)
const transform110 = new Transform({
  position: new Vector3(40.02092361450195, 3.9671449661254883, 25.4946346282959),
  rotation: new Quaternion(0.6151092052459717, 0.24601049721240997, 0.7488032579421997, 0.02032889798283577),
  scale: new Vector3(1, 1, 1)
})
cyanMagicStone15.addComponentOrReplace(transform110)

const cyanMagicStone16 = new Entity('cyanMagicStone16')
engine.addEntity(cyanMagicStone16)
cyanMagicStone16.setParent(_scene)
cyanMagicStone16.addComponentOrReplace(gltfShape7)
const transform111 = new Transform({
  position: new Vector3(40.34807205200195, 0.047814369201660156, 32.986412048339844),
  rotation: new Quaternion(-0.39268532395362854, -0.8255324959754944, 0.16097746789455414, 0.3719955384731293),
  scale: new Vector3(1.8952772617340088, 1.3253177404403687, 2.1645965576171875)
})
cyanMagicStone16.addComponentOrReplace(transform111)

const cyanMagicStone17 = new Entity('cyanMagicStone17')
engine.addEntity(cyanMagicStone17)
cyanMagicStone17.setParent(_scene)
cyanMagicStone17.addComponentOrReplace(gltfShape7)
const transform112 = new Transform({
  position: new Vector3(38.290733337402344, 0.047814369201660156, 30.539644241333008),
  rotation: new Quaternion(-0.39268532395362854, -0.8255324959754944, 0.16097746789455414, 0.3719955384731293),
  scale: new Vector3(1.4099714756011963, 0.8400119543075562, 1.679290771484375)
})
cyanMagicStone17.addComponentOrReplace(transform112)

const cyanMagicStone18 = new Entity('cyanMagicStone18')
engine.addEntity(cyanMagicStone18)
cyanMagicStone18.setParent(_scene)
cyanMagicStone18.addComponentOrReplace(gltfShape7)
const transform113 = new Transform({
  position: new Vector3(36.19879913330078, 0.047814369201660156, 20.479536056518555),
  rotation: new Quaternion(-0.39268532395362854, -0.8255324959754944, 0.16097746789455414, 0.3719955384731293),
  scale: new Vector3(1.4099714756011963, 0.8400119543075562, 1.679290771484375)
})
cyanMagicStone18.addComponentOrReplace(transform113)

const cyanMagicStone19 = new Entity('cyanMagicStone19')
engine.addEntity(cyanMagicStone19)
cyanMagicStone19.setParent(_scene)
cyanMagicStone19.addComponentOrReplace(gltfShape7)
const transform114 = new Transform({
  position: new Vector3(43.07017135620117, 1.4955976009368896, 33.58403396606445),
  rotation: new Quaternion(0.905517578125, -0.12547318637371063, 0.3061385452747345, -0.2656570076942444),
  scale: new Vector3(1.8952772617340088, 1.3253177404403687, 2.1645965576171875)
})
cyanMagicStone19.addComponentOrReplace(transform114)

const penguin = new Entity('penguin')
engine.addEntity(penguin)
penguin.setParent(_scene)
const transform115 = new Transform({
  position: new Vector3(43.32383728027344, 0.17758965492248535, 20.90900993347168),
  rotation: new Quaternion(-2.7772179578977466e-15, 0.9999781250953674, -1.1920666054265894e-7, 0.006627227179706097),
  scale: new Vector3(0.414337158203125, 0.414337158203125, 0.414337158203125)
})
penguin.addComponentOrReplace(transform115)
const gltfShape8 = new GLTFShape("models/penguin.glb")
gltfShape8.withCollisions = true
gltfShape8.visible = true
penguin.addComponentOrReplace(gltfShape8)

const shovel = new Entity('shovel')
engine.addEntity(shovel)
shovel.setParent(_scene)
const transform116 = new Transform({
  position: new Vector3(43.661109924316406, 0, 22.563953399658203),
  rotation: new Quaternion(0.10911481827497482, -1.127526336094398e-17, -1.3007498189665512e-8, 0.9940292239189148),
  scale: new Vector3(0.0741729736328125, 0.0741729736328125, 0.0741729736328125)
})
shovel.addComponentOrReplace(transform116)
const gltfShape9 = new GLTFShape("models/shovel.glb")
gltfShape9.withCollisions = true
gltfShape9.visible = true
shovel.addComponentOrReplace(gltfShape9)

const pickaxe = new Entity('pickaxe')
engine.addEntity(pickaxe)
pickaxe.setParent(_scene)
const transform117 = new Transform({
  position: new Vector3(14.501362800598145, 10.368281364440918, 100),
  rotation: new Quaternion(0.009763587266206741, 0.2843257188796997, -0.2263180911540985, 0.9315813183784485),
  scale: new Vector3(0.11062145233154297, 0.11062145233154297, 0.11062145233154297)
})
pickaxe.addComponentOrReplace(transform117)
const gltfShape10 = new GLTFShape("models/pickaxe.glb")
gltfShape10.withCollisions = true
gltfShape10.visible = true
pickaxe.addComponentOrReplace(gltfShape10)

const santa = new Entity('santa')
engine.addEntity(santa)
santa.setParent(_scene)
const transform118 = new Transform({
  position: new Vector3(28.89885711669922, 26.38467788696289, 106.55043029785156),
  rotation: new Quaternion(4.755777126038004e-16, -0.7057154774665833, 8.412784069378176e-8, 0.7084954380989075),
  scale: new Vector3(1.9413795471191406, 1.9413795471191406, 1.9413795471191406)
})
santa.addComponentOrReplace(transform118)
const gltfShape11 = new GLTFShape("models/Santa.glb")
gltfShape11.withCollisions = true
gltfShape11.visible = true
santa.addComponentOrReplace(gltfShape11)

const iceboulder2 = new Entity('iceboulder2')
engine.addEntity(iceboulder2)
iceboulder2.setParent(_scene)
const gltfShape12 = new GLTFShape("models/iceboulder.glb")
gltfShape12.withCollisions = true
gltfShape12.visible = true
iceboulder2.addComponentOrReplace(gltfShape12)
const transform119 = new Transform({
  position: new Vector3(25.142822265625, 0.9837346076965332, 25.156574249267578),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.5394172668457031, 1.5394172668457031, 1.5394172668457031)
})
iceboulder2.addComponentOrReplace(transform119)

const crashedsleigh = new Entity('crashedsleigh')
engine.addEntity(crashedsleigh)
crashedsleigh.setParent(_scene)
const transform120 = new Transform({
  position: new Vector3(25.92220687866211, 25.203779220581055, 108.60743713378906),
  rotation: new Quaternion(0.16418349742889404, -0.8755041360855103, -0.16563129425048828, -0.42320525646209717),
  scale: new Vector3(1.7525138854980469, 1.7525138854980469, 1.7525138854980469)
})
crashedsleigh.addComponentOrReplace(transform120)
const gltfShape13 = new GLTFShape("models/CrashedSleigh.glb")
gltfShape13.withCollisions = true
gltfShape13.visible = true
crashedsleigh.addComponentOrReplace(gltfShape13)

const bsnowpile = new Entity('bsnowpile')
engine.addEntity(bsnowpile)
bsnowpile.setParent(_scene)
const transform121 = new Transform({
  position: new Vector3(54.86686325073242, 0, 27.28234100341797),
  rotation: new Quaternion(-1.395363431428516e-16, 0.205867201089859, -2.4541277454659394e-8, 0.9785799384117126),
  scale: new Vector3(2.383544921875, 2.383544921875, 2.383544921875)
})
bsnowpile.addComponentOrReplace(transform121)
const gltfShape14 = new GLTFShape("models/BSnowPile.glb")
gltfShape14.withCollisions = true
gltfShape14.visible = true
bsnowpile.addComponentOrReplace(gltfShape14)

const campfire = new Entity('campfire')
engine.addEntity(campfire)
campfire.setParent(_scene)
const transform122 = new Transform({
  position: new Vector3(29.903854370117188, 0.18103086948394775, 42.261810302734375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
campfire.addComponentOrReplace(transform122)
const gltfShape15 = new GLTFShape("models/Fireplace_01/Fireplace_01.glb")
gltfShape15.withCollisions = true
gltfShape15.visible = true
campfire.addComponentOrReplace(gltfShape15)

const cookingTripod = new Entity('cookingTripod')
engine.addEntity(cookingTripod)
cookingTripod.setParent(_scene)
const transform123 = new Transform({
  position: new Vector3(29.88393211364746, 0.13972234725952148, 42.04228973388672),
  rotation: new Quaternion(4.2733968388952454e-15, 0.8616182804107666, -1.0271288175545124e-7, 0.5075569152832031),
  scale: new Vector3(2.8079166412353516, 2.8079166412353516, 2.8079166412353516)
})
cookingTripod.addComponentOrReplace(transform123)
const gltfShape16 = new GLTFShape("models/HangingStructure_01/HangingStructure_01.glb")
gltfShape16.withCollisions = true
gltfShape16.visible = true
cookingTripod.addComponentOrReplace(gltfShape16)

const silverFish = new Entity('silverFish')
engine.addEntity(silverFish)
silverFish.setParent(_scene)
const transform124 = new Transform({
  position: new Vector3(29.912729263305664, 2.741389513015747, 42.071571350097656),
  rotation: new Quaternion(0.3677753806114197, 0.3621922433376312, -0.6047012805938721, -0.6065431237220764),
  scale: new Vector3(4.21263313293457, 4.21263313293457, 4.21263313293457)
})
silverFish.addComponentOrReplace(transform124)
const gltfShape17 = new GLTFShape("models/Fish_01/Fish_01.glb")
gltfShape17.withCollisions = true
gltfShape17.visible = true
silverFish.addComponentOrReplace(gltfShape17)

const penguin2 = new Entity('penguin2')
engine.addEntity(penguin2)
penguin2.setParent(_scene)
const transform125 = new Transform({
  position: new Vector3(30.801862716674805, 0.23622667789459229, 39.14949417114258),
  rotation: new Quaternion(-6.133022522724751e-15, -0.8308631777763367, 9.90466020311942e-8, 0.5564767718315125),
  scale: new Vector3(0.44669342041015625, 0.44669342041015625, 0.44669342041015625)
})
penguin2.addComponentOrReplace(transform125)
penguin2.addComponentOrReplace(gltfShape8)

const penguin3 = new Entity('penguin3')
engine.addEntity(penguin3)
penguin3.setParent(_scene)
penguin3.addComponentOrReplace(gltfShape8)
const transform126 = new Transform({
  position: new Vector3(32.600440979003906, 0.12328898906707764, 42.101131439208984),
  rotation: new Quaternion(-1.394125005732159e-14, -0.9963415861129761, 1.1877317263042642e-7, -0.08546032011508942),
  scale: new Vector3(0.44669342041015625, 0.44669342041015625, 0.44669342041015625)
})
penguin3.addComponentOrReplace(transform126)

const penguin4 = new Entity('penguin4')
engine.addEntity(penguin4)
penguin4.setParent(_scene)
penguin4.addComponentOrReplace(gltfShape8)
const transform127 = new Transform({
  position: new Vector3(29.163183212280273, 0.11815690994262695, 27.03350830078125),
  rotation: new Quaternion(-1.2397314823483184e-14, -0.9717379212379456, 1.1584018011490116e-7, -0.2360624223947525),
  scale: new Vector3(0.44669342041015625, 0.44669342041015625, 0.44669342041015625)
})
penguin4.addComponentOrReplace(transform127)

const druidWoodenRoundTable = new Entity('druidWoodenRoundTable')
engine.addEntity(druidWoodenRoundTable)
druidWoodenRoundTable.setParent(_scene)
const transform128 = new Transform({
  position: new Vector3(26.15060806274414, 0.3004336357116699, 36.97450637817383),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
druidWoodenRoundTable.addComponentOrReplace(transform128)
const gltfShape18 = new GLTFShape("models/WoodRoundTable_01/WoodRoundTable_01.glb")
gltfShape18.withCollisions = true
gltfShape18.visible = true
druidWoodenRoundTable.addComponentOrReplace(gltfShape18)

const redFish = new Entity('redFish')
engine.addEntity(redFish)
redFish.setParent(_scene)
const transform129 = new Transform({
  position: new Vector3(26.39609146118164, 1.0797491073608398, 36.88905334472656),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.997333526611328, 3.997333526611328, 3.997333526611328)
})
redFish.addComponentOrReplace(transform129)
const gltfShape19 = new GLTFShape("models/Fish_02/Fish_02.glb")
gltfShape19.withCollisions = true
gltfShape19.visible = true
redFish.addComponentOrReplace(gltfShape19)

const silverFork = new Entity('silverFork')
engine.addEntity(silverFork)
silverFork.setParent(_scene)
const transform130 = new Transform({
  position: new Vector3(26.414461135864258, 1.7457940578460693, 36.984779357910156),
  rotation: new Quaternion(-0.6993789672851562, -5.708065246054321e-15, 8.337244850054049e-8, 0.7147510051727295),
  scale: new Vector3(2.7791061401367188, 2.7791061401367188, 2.7791061401367188)
})
silverFork.addComponentOrReplace(transform130)
const gltfShape20 = new GLTFShape("models/Fork_01/Fork_01.glb")
gltfShape20.withCollisions = true
gltfShape20.visible = true
silverFork.addComponentOrReplace(gltfShape20)

const penguin5 = new Entity('penguin5')
engine.addEntity(penguin5)
penguin5.setParent(_scene)
penguin5.addComponentOrReplace(gltfShape8)
const transform131 = new Transform({
  position: new Vector3(27.332645416259766, 0.3788045644760132, 38.19090270996094),
  rotation: new Quaternion(-1.3499207279072094e-14, 0.8694146871566772, -1.0364230718096223e-7, 0.49408313632011414),
  scale: new Vector3(0.44669342041015625, 0.44669342041015625, 0.44669342041015625)
})
penguin5.addComponentOrReplace(transform131)

const yeti = new Entity('yeti')
engine.addEntity(yeti)
yeti.setParent(_scene)
const transform132 = new Transform({
  position: new Vector3(47.32875061035156, 0.6146636009216309, 94.48896026611328),
  rotation: new Quaternion(3.0290552526765534e-15, 0.9419139623641968, -1.1228488006054249e-7, -0.33585453033447266),
  scale: new Vector3(0.4530792236328125, 0.4530792236328125, 0.4530792236328125)
})
yeti.addComponentOrReplace(transform132)
const gltfShape21 = new GLTFShape("models/Yeti.glb")
gltfShape21.withCollisions = true
gltfShape21.visible = true
yeti.addComponentOrReplace(gltfShape21)

const bigBone = new Entity('bigBone')
engine.addEntity(bigBone)
bigBone.setParent(_scene)
const transform133 = new Transform({
  position: new Vector3(42.154579162597656, 0.11493408679962158, 82.12608337402344),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone.addComponentOrReplace(transform133)
const gltfShape22 = new GLTFShape("models/BonesBig_01/BonesBig_01.glb")
gltfShape22.withCollisions = true
gltfShape22.visible = true
bigBone.addComponentOrReplace(gltfShape22)

const bigBone2 = new Entity('bigBone2')
engine.addEntity(bigBone2)
bigBone2.setParent(_scene)
bigBone2.addComponentOrReplace(gltfShape22)
const transform134 = new Transform({
  position: new Vector3(43.43598175048828, 0.11493408679962158, 82.12608337402344),
  rotation: new Quaternion(-6.933640976145272e-17, 0.2589879631996155, -3.087377109523004e-8, 0.9658805727958679),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone2.addComponentOrReplace(transform134)

const bigBone3 = new Entity('bigBone3')
engine.addEntity(bigBone3)
bigBone3.setParent(_scene)
bigBone3.addComponentOrReplace(gltfShape22)
const transform135 = new Transform({
  position: new Vector3(45.121517181396484, 0.11493408679962158, 83.18274688720703),
  rotation: new Quaternion(3.021938270095486e-15, -0.2491401880979538, 2.9699814163564042e-8, 0.9684674739837646),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone3.addComponentOrReplace(transform135)

const bigBone4 = new Entity('bigBone4')
engine.addEntity(bigBone4)
bigBone4.setParent(_scene)
bigBone4.addComponentOrReplace(gltfShape22)
const transform136 = new Transform({
  position: new Vector3(45.21234130859375, 0.11493408679962158, 81.43772888183594),
  rotation: new Quaternion(4.669124702621824e-15, -0.42585334181785583, 5.0765656567364204e-8, 0.9047921895980835),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone4.addComponentOrReplace(transform136)

const bigBone5 = new Entity('bigBone5')
engine.addEntity(bigBone5)
bigBone5.setParent(_scene)
bigBone5.addComponentOrReplace(gltfShape22)
const transform137 = new Transform({
  position: new Vector3(45.21234130859375, 0.11493408679962158, 81.43772888183594),
  rotation: new Quaternion(4.669124702621824e-15, -0.42585334181785583, 5.0765656567364204e-8, 0.9047921895980835),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone5.addComponentOrReplace(transform137)

const bigBone6 = new Entity('bigBone6')
engine.addEntity(bigBone6)
bigBone6.setParent(_scene)
bigBone6.addComponentOrReplace(gltfShape22)
const transform138 = new Transform({
  position: new Vector3(46.7314567565918, 0.11493408679962158, 82.75703430175781),
  rotation: new Quaternion(3.939503227351178e-15, -0.40203189849853516, 4.792592278590746e-8, 0.9156256318092346),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone6.addComponentOrReplace(transform138)

const bigBone7 = new Entity('bigBone7')
engine.addEntity(bigBone7)
bigBone7.setParent(_scene)
bigBone7.addComponentOrReplace(gltfShape22)
const transform139 = new Transform({
  position: new Vector3(51.46936798095703, 0.11493408679962158, 84.4994125366211),
  rotation: new Quaternion(8.097855204317397e-15, -0.9606716632843018, 1.1452096515540688e-7, -0.2776869237422943),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone7.addComponentOrReplace(transform139)

const bigBone8 = new Entity('bigBone8')
engine.addEntity(bigBone8)
bigBone8.setParent(_scene)
bigBone8.addComponentOrReplace(gltfShape22)
const transform140 = new Transform({
  position: new Vector3(49.882225036621094, 0.11493408679962158, 84.25689697265625),
  rotation: new Quaternion(5.015942342875097e-15, -0.5478853583335876, 6.531301011136748e-8, 0.8365533947944641),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone8.addComponentOrReplace(transform140)

const bigBone9 = new Entity('bigBone9')
engine.addEntity(bigBone9)
bigBone9.setParent(_scene)
bigBone9.addComponentOrReplace(gltfShape22)
const transform141 = new Transform({
  position: new Vector3(50.65123748779297, 0.11493408679962158, 86.24513244628906),
  rotation: new Quaternion(5.015942342875097e-15, -0.5478853583335876, 6.531301011136748e-8, 0.8365533947944641),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone9.addComponentOrReplace(transform141)

const bigBone10 = new Entity('bigBone10')
engine.addEntity(bigBone10)
bigBone10.setParent(_scene)
bigBone10.addComponentOrReplace(gltfShape22)
const transform142 = new Transform({
  position: new Vector3(51.37113952636719, 0.11493408679962158, 82.28353118896484),
  rotation: new Quaternion(5.8424859866517895e-15, -0.8333998918533325, 9.934899480867898e-8, 0.5526705384254456),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone10.addComponentOrReplace(transform142)

const bigBone11 = new Entity('bigBone11')
engine.addEntity(bigBone11)
bigBone11.setParent(_scene)
bigBone11.addComponentOrReplace(gltfShape22)
const transform143 = new Transform({
  position: new Vector3(51.885284423828125, 0.11493408679962158, 80.3502197265625),
  rotation: new Quaternion(3.6452664278481366e-15, -0.33791181445121765, 4.028221312069036e-8, 0.9411777853965759),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone11.addComponentOrReplace(transform143)

const bigBone12 = new Entity('bigBone12')
engine.addEntity(bigBone12)
bigBone12.setParent(_scene)
bigBone12.addComponentOrReplace(gltfShape22)
const transform144 = new Transform({
  position: new Vector3(51.57038497924805, 0.11493408679962158, 78.5381851196289),
  rotation: new Quaternion(6.577709737835575e-15, -0.6747108101844788, 8.043178212346902e-8, -0.7380821704864502),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone12.addComponentOrReplace(transform144)

const bigBone13 = new Entity('bigBone13')
engine.addEntity(bigBone13)
bigBone13.setParent(_scene)
bigBone13.addComponentOrReplace(gltfShape22)
const transform145 = new Transform({
  position: new Vector3(49.687767028808594, 0.11493408679962158, 77.51570129394531),
  rotation: new Quaternion(3.703460555939822e-15, -0.37244075536727905, 4.439838363623494e-8, 0.928056001663208),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone13.addComponentOrReplace(transform145)

const bigBone14 = new Entity('bigBone14')
engine.addEntity(bigBone14)
bigBone14.setParent(_scene)
bigBone14.addComponentOrReplace(gltfShape22)
const transform146 = new Transform({
  position: new Vector3(47.829315185546875, 0.11493408679962158, 77.28594970703125),
  rotation: new Quaternion(-1.5669294254992824e-15, 0.08980192989110947, -1.0705216269002449e-8, -0.9959596395492554),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone14.addComponentOrReplace(transform146)

const bigBone15 = new Entity('bigBone15')
engine.addEntity(bigBone15)
bigBone15.setParent(_scene)
bigBone15.addComponentOrReplace(gltfShape22)
const transform147 = new Transform({
  position: new Vector3(46.08701705932617, 0.11493408679962158, 76.72285461425781),
  rotation: new Quaternion(-2.1172871771536327e-15, -0.15185675024986267, 1.810273708713339e-8, -0.9884025454521179),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone15.addComponentOrReplace(transform147)

const bigBone16 = new Entity('bigBone16')
engine.addEntity(bigBone16)
bigBone16.setParent(_scene)
bigBone16.addComponentOrReplace(gltfShape22)
const transform148 = new Transform({
  position: new Vector3(47.05107498168945, 0.11493408679962158, 76.59334564208984),
  rotation: new Quaternion(3.703460555939822e-15, -0.37244075536727905, 4.439838363623494e-8, 0.928056001663208),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone16.addComponentOrReplace(transform148)

const bigBone17 = new Entity('bigBone17')
engine.addEntity(bigBone17)
bigBone17.setParent(_scene)
bigBone17.addComponentOrReplace(gltfShape22)
const transform149 = new Transform({
  position: new Vector3(46.45696258544922, 0.11493408679962158, 74.18217468261719),
  rotation: new Quaternion(1.2857878824157343e-14, -0.997775673866272, 1.1894412210722294e-7, -0.06666233390569687),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone17.addComponentOrReplace(transform149)

const bigBone18 = new Entity('bigBone18')
engine.addEntity(bigBone18)
bigBone18.setParent(_scene)
bigBone18.addComponentOrReplace(gltfShape22)
const transform150 = new Transform({
  position: new Vector3(48.5092658996582, 0.11493408679962158, 74.27740478515625),
  rotation: new Quaternion(1.0739391824833924e-14, -0.8422534465789795, 1.0040442077752232e-7, 0.539081871509552),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone18.addComponentOrReplace(transform150)

const bigBone19 = new Entity('bigBone19')
engine.addEntity(bigBone19)
bigBone19.setParent(_scene)
bigBone19.addComponentOrReplace(gltfShape22)
const transform151 = new Transform({
  position: new Vector3(50.52911376953125, 0.11493408679962158, 74.7965087890625),
  rotation: new Quaternion(1.1363006279722747e-15, -0.1634901762008667, 1.948953354258265e-8, 0.9865449666976929),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone19.addComponentOrReplace(transform151)

const bigBone20 = new Entity('bigBone20')
engine.addEntity(bigBone20)
bigBone20.setParent(_scene)
bigBone20.addComponentOrReplace(gltfShape22)
const transform152 = new Transform({
  position: new Vector3(52.606998443603516, 0.11493408679962158, 73.0318374633789),
  rotation: new Quaternion(4.833585043177192e-15, -0.4466981589794159, 5.325054885929603e-8, 0.8946847915649414),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone20.addComponentOrReplace(transform152)

const bigBone21 = new Entity('bigBone21')
engine.addEntity(bigBone21)
bigBone21.setParent(_scene)
bigBone21.addComponentOrReplace(gltfShape22)
const transform153 = new Transform({
  position: new Vector3(52.06023406982422, 0.11493408679962158, 75.88935852050781),
  rotation: new Quaternion(4.833585043177192e-15, -0.4466981589794159, 5.325054885929603e-8, 0.8946847915649414),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone21.addComponentOrReplace(transform153)

const bigBone22 = new Entity('bigBone22')
engine.addEntity(bigBone22)
bigBone22.setParent(_scene)
bigBone22.addComponentOrReplace(gltfShape22)
const transform154 = new Transform({
  position: new Vector3(52.923221588134766, 0.11493408679962158, 70.52950286865234),
  rotation: new Quaternion(8.045856381081048e-16, -0.22508350014686584, 2.6832022825828972e-8, 0.9743395447731018),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone22.addComponentOrReplace(transform154)

const bigBone23 = new Entity('bigBone23')
engine.addEntity(bigBone23)
bigBone23.setParent(_scene)
bigBone23.addComponentOrReplace(gltfShape22)
const transform155 = new Transform({
  position: new Vector3(41.00109100341797, 0.11493408679962158, 73.43167114257812),
  rotation: new Quaternion(8.045856381081048e-16, -0.22508350014686584, 2.6832022825828972e-8, 0.9743395447731018),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone23.addComponentOrReplace(transform155)

const bigBone24 = new Entity('bigBone24')
engine.addEntity(bigBone24)
bigBone24.setParent(_scene)
bigBone24.addComponentOrReplace(gltfShape22)
const transform156 = new Transform({
  position: new Vector3(42.78584671020508, 0.11493408679962158, 72.06121826171875),
  rotation: new Quaternion(5.856282035780194e-15, -0.14678363502025604, 1.7497988835657452e-8, -0.9891687035560608),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone24.addComponentOrReplace(transform156)

const bigBone25 = new Entity('bigBone25')
engine.addEntity(bigBone25)
bigBone25.setParent(_scene)
bigBone25.addComponentOrReplace(gltfShape22)
const transform157 = new Transform({
  position: new Vector3(44.2337760925293, 0.11493408679962158, 70.24810791015625),
  rotation: new Quaternion(-2.950244342648698e-15, -0.017594028264284134, 2.097353180019468e-9, 0.9998452663421631),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone25.addComponentOrReplace(transform157)

const bigBone26 = new Entity('bigBone26')
engine.addEntity(bigBone26)
bigBone26.setParent(_scene)
bigBone26.addComponentOrReplace(gltfShape22)
const transform158 = new Transform({
  position: new Vector3(43.070980072021484, 0.11493408679962158, 68.75877380371094),
  rotation: new Quaternion(1.8333591921351495e-15, -0.31875351071357727, 3.7998354684987135e-8, 0.9478377103805542),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone26.addComponentOrReplace(transform158)

const bigBone27 = new Entity('bigBone27')
engine.addEntity(bigBone27)
bigBone27.setParent(_scene)
bigBone27.addComponentOrReplace(gltfShape22)
const transform159 = new Transform({
  position: new Vector3(45.428287506103516, 0.11493408679962158, 67.70345306396484),
  rotation: new Quaternion(1.0953659820270214e-14, -0.4155901372432709, 4.954221921593671e-8, -0.9095520377159119),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone27.addComponentOrReplace(transform159)

const bigBone28 = new Entity('bigBone28')
engine.addEntity(bigBone28)
bigBone28.setParent(_scene)
bigBone28.addComponentOrReplace(gltfShape22)
const transform160 = new Transform({
  position: new Vector3(43.25785827636719, 0.11493408679962158, 66.0966567993164),
  rotation: new Quaternion(8.706173091211755e-15, -0.697741687297821, 8.317726951645454e-8, 0.7163495421409607),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone28.addComponentOrReplace(transform160)

const bigBone29 = new Entity('bigBone29')
engine.addEntity(bigBone29)
bigBone29.setParent(_scene)
bigBone29.addComponentOrReplace(gltfShape22)
const transform161 = new Transform({
  position: new Vector3(47.701805114746094, 0.11493408679962158, 69.75728607177734),
  rotation: new Quaternion(-2.2544447659069745e-14, 0.8186038732528687, -9.758520036484697e-8, 0.5743585228919983),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone29.addComponentOrReplace(transform161)

const bigBone30 = new Entity('bigBone30')
engine.addEntity(bigBone30)
bigBone30.setParent(_scene)
bigBone30.addComponentOrReplace(gltfShape22)
const transform162 = new Transform({
  position: new Vector3(49.679771423339844, 0.11493408679962158, 69.80412292480469),
  rotation: new Quaternion(-3.453237113035419e-14, -0.08002665638923645, 9.539931511426403e-9, -0.996792733669281),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone30.addComponentOrReplace(transform162)

const bigBone31 = new Entity('bigBone31')
engine.addEntity(bigBone31)
bigBone31.setParent(_scene)
bigBone31.addComponentOrReplace(gltfShape22)
const transform163 = new Transform({
  position: new Vector3(47.61324691772461, 0.11493408679962158, 67.46407318115234),
  rotation: new Quaternion(2.368465056783002e-15, 0.05420094355940819, -6.461238655219859e-9, -0.9985300898551941),
  scale: new Vector3(2.083171844482422, 2.083171844482422, 2.083171844482422)
})
bigBone31.addComponentOrReplace(transform163)

const beachBones = new Entity('beachBones')
engine.addEntity(beachBones)
beachBones.setParent(_scene)
const transform164 = new Transform({
  position: new Vector3(43.92298126220703, 0.10596919059753418, 80.8321762084961),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6119804382324219, 1.6119804382324219, 1.6119804382324219)
})
beachBones.addComponentOrReplace(transform164)
const gltfShape23 = new GLTFShape("models/BonesChest_01/BonesChest_01.glb")
gltfShape23.withCollisions = true
gltfShape23.visible = true
beachBones.addComponentOrReplace(gltfShape23)

const beachBones2 = new Entity('beachBones2')
engine.addEntity(beachBones2)
beachBones2.setParent(_scene)
beachBones2.addComponentOrReplace(gltfShape23)
const transform165 = new Transform({
  position: new Vector3(50.842308044433594, 0.10596919059753418, 79.8871078491211),
  rotation: new Quaternion(8.00754349268996e-16, -0.4765797555446625, 5.681272341462318e-8, 0.8791312575340271),
  scale: new Vector3(1.6119804382324219, 1.6119804382324219, 1.6119804382324219)
})
beachBones2.addComponentOrReplace(transform165)

const beachBones3 = new Entity('beachBones3')
engine.addEntity(beachBones3)
beachBones3.setParent(_scene)
beachBones3.addComponentOrReplace(gltfShape23)
const transform166 = new Transform({
  position: new Vector3(45.41553497314453, 0.10596919059753418, 69.76216125488281),
  rotation: new Quaternion(-8.441537975632882e-15, -0.937104344367981, 1.117115218107756e-7, -0.34904956817626953),
  scale: new Vector3(1.6119804382324219, 1.6119804382324219, 1.6119804382324219)
})
beachBones3.addComponentOrReplace(transform166)

const beachBones4 = new Entity('beachBones4')
engine.addEntity(beachBones4)
beachBones4.setParent(_scene)
beachBones4.addComponentOrReplace(gltfShape23)
const transform167 = new Transform({
  position: new Vector3(49.09268569946289, 0.10596919059753418, 75.67292022705078),
  rotation: new Quaternion(-5.171529880959079e-17, -0.30423489212989807, 3.626761824193636e-8, -0.9525970816612244),
  scale: new Vector3(1.6119804382324219, 1.6119804382324219, 1.6119804382324219)
})
beachBones4.addComponentOrReplace(transform167)

const skull = new Entity('skull')
engine.addEntity(skull)
skull.setParent(_scene)
const transform168 = new Transform({
  position: new Vector3(46.5, 0, 81.5),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
skull.addComponentOrReplace(transform168)
const gltfShape24 = new GLTFShape("models/BonesSkull_01/BonesSkull_01.glb")
gltfShape24.withCollisions = true
gltfShape24.visible = true
skull.addComponentOrReplace(gltfShape24)

const skull2 = new Entity('skull2')
engine.addEntity(skull2)
skull2.setParent(_scene)
skull2.addComponentOrReplace(gltfShape24)
const transform169 = new Transform({
  position: new Vector3(52.50070571899414, 0, 81.1028823852539),
  rotation: new Quaternion(-9.9790687933571e-16, -0.4643300771713257, 5.5352458616653166e-8, 0.8856622576713562),
  scale: new Vector3(1, 1, 1)
})
skull2.addComponentOrReplace(transform169)

const skull3 = new Entity('skull3')
engine.addEntity(skull3)
skull3.setParent(_scene)
skull3.addComponentOrReplace(gltfShape24)
const transform170 = new Transform({
  position: new Vector3(47.3115234375, 0, 75.427978515625),
  rotation: new Quaternion(-9.9790687933571e-16, -0.4643300771713257, 5.5352458616653166e-8, 0.8856622576713562),
  scale: new Vector3(1, 1, 1)
})
skull3.addComponentOrReplace(transform170)

const skull4 = new Entity('skull4')
engine.addEntity(skull4)
skull4.setParent(_scene)
skull4.addComponentOrReplace(gltfShape24)
const transform171 = new Transform({
  position: new Vector3(43.36735534667969, 0, 69.9127197265625),
  rotation: new Quaternion(3.9615993523297276e-15, 0.202651247382164, -2.4157914779721068e-8, 0.9792510271072388),
  scale: new Vector3(1, 1, 1)
})
skull4.addComponentOrReplace(transform171)

const penguin6 = new Entity('penguin6')
engine.addEntity(penguin6)
penguin6.setParent(_scene)
penguin6.addComponentOrReplace(gltfShape8)
const transform172 = new Transform({
  position: new Vector3(40.66773986816406, 7.794122695922852, 82.83452606201172),
  rotation: new Quaternion(-1.1415546039375037e-14, -0.959538996219635, 1.1438595493018511e-7, -0.2815757691860199),
  scale: new Vector3(0.44669342041015625, 0.44669342041015625, 0.44669342041015625)
})
penguin6.addComponentOrReplace(transform172)

const penguin7 = new Entity('penguin7')
engine.addEntity(penguin7)
penguin7.setParent(_scene)
penguin7.addComponentOrReplace(gltfShape8)
const transform173 = new Transform({
  position: new Vector3(22.599937438964844, 7.423159599304199, 72.45476531982422),
  rotation: new Quaternion(1.0076453018335874e-14, -0.2364148050546646, 2.818286226613509e-8, 0.9716522693634033),
  scale: new Vector3(0.44669342041015625, 0.44669342041015625, 0.44669342041015625)
})
penguin7.addComponentOrReplace(transform173)

const snowpile2 = new Entity('snowpile2')
engine.addEntity(snowpile2)
snowpile2.setParent(_scene)
snowpile2.addComponentOrReplace(gltfShape6)
const transform174 = new Transform({
  position: new Vector3(35.69463348388672, 0, 76.8890151977539),
  rotation: new Quaternion(6.899213586701917e-16, -0.3669753670692444, 4.374686213282075e-8, 0.9302306771278381),
  scale: new Vector3(0.6899713277816772, 1, 1)
})
snowpile2.addComponentOrReplace(transform174)

const snowypine15 = new Entity('snowypine15')
engine.addEntity(snowypine15)
snowypine15.setParent(_scene)
snowypine15.addComponentOrReplace(gltfShape4)
const transform175 = new Transform({
  position: new Vector3(3.4544930458068848, 0, 52.745975494384766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine15.addComponentOrReplace(transform175)

const snowypine16 = new Entity('snowypine16')
engine.addEntity(snowypine16)
snowypine16.setParent(_scene)
snowypine16.addComponentOrReplace(gltfShape4)
const transform176 = new Transform({
  position: new Vector3(12.611587524414062, 0, 51.08766555786133),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine16.addComponentOrReplace(transform176)

const snowypine17 = new Entity('snowypine17')
engine.addEntity(snowypine17)
snowypine17.setParent(_scene)
snowypine17.addComponentOrReplace(gltfShape4)
const transform177 = new Transform({
  position: new Vector3(14.581143379211426, 0, 53.848445892333984),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine17.addComponentOrReplace(transform177)

const snowypine18 = new Entity('snowypine18')
engine.addEntity(snowypine18)
snowypine18.setParent(_scene)
snowypine18.addComponentOrReplace(gltfShape4)
const transform178 = new Transform({
  position: new Vector3(21.15581512451172, 0, 59.07695007324219),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine18.addComponentOrReplace(transform178)

const snowypine21 = new Entity('snowypine21')
engine.addEntity(snowypine21)
snowypine21.setParent(_scene)
snowypine21.addComponentOrReplace(gltfShape4)
const transform179 = new Transform({
  position: new Vector3(20.070167541503906, 0, 6.0512542724609375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine21.addComponentOrReplace(transform179)

const snowypine22 = new Entity('snowypine22')
engine.addEntity(snowypine22)
snowypine22.setParent(_scene)
snowypine22.addComponentOrReplace(gltfShape4)
const transform180 = new Transform({
  position: new Vector3(23.010272979736328, 0, 3.4934520721435547),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine22.addComponentOrReplace(transform180)

const snowypine23 = new Entity('snowypine23')
engine.addEntity(snowypine23)
snowypine23.setParent(_scene)
snowypine23.addComponentOrReplace(gltfShape4)
const transform181 = new Transform({
  position: new Vector3(60.92328643798828, 0, 6.132441520690918),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine23.addComponentOrReplace(transform181)

const snowypine24 = new Entity('snowypine24')
engine.addEntity(snowypine24)
snowypine24.setParent(_scene)
snowypine24.addComponentOrReplace(gltfShape4)
const transform182 = new Transform({
  position: new Vector3(57.280643463134766, 0, 4.024803638458252),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine24.addComponentOrReplace(transform182)

const snowypine25 = new Entity('snowypine25')
engine.addEntity(snowypine25)
snowypine25.setParent(_scene)
snowypine25.addComponentOrReplace(gltfShape4)
const transform183 = new Transform({
  position: new Vector3(59.777557373046875, 0, 20.045021057128906),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine25.addComponentOrReplace(transform183)

const snowypine26 = new Entity('snowypine26')
engine.addEntity(snowypine26)
snowypine26.setParent(_scene)
snowypine26.addComponentOrReplace(gltfShape4)
const transform184 = new Transform({
  position: new Vector3(43.37908172607422, 0, 11.003517150878906),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine26.addComponentOrReplace(transform184)

const snowypine27 = new Entity('snowypine27')
engine.addEntity(snowypine27)
snowypine27.setParent(_scene)
snowypine27.addComponentOrReplace(gltfShape4)
const transform185 = new Transform({
  position: new Vector3(40.613487243652344, 0, 8.74575424194336),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine27.addComponentOrReplace(transform185)

const snowypine28 = new Entity('snowypine28')
engine.addEntity(snowypine28)
snowypine28.setParent(_scene)
snowypine28.addComponentOrReplace(gltfShape4)
const transform186 = new Transform({
  position: new Vector3(44.95857238769531, 0, 7.323525428771973),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine28.addComponentOrReplace(transform186)

const snowypine30 = new Entity('snowypine30')
engine.addEntity(snowypine30)
snowypine30.setParent(_scene)
snowypine30.addComponentOrReplace(gltfShape4)
const transform187 = new Transform({
  position: new Vector3(7.597785949707031, 0, 114.4043960571289),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine30.addComponentOrReplace(transform187)

const snowypine31 = new Entity('snowypine31')
engine.addEntity(snowypine31)
snowypine31.setParent(_scene)
snowypine31.addComponentOrReplace(gltfShape4)
const transform188 = new Transform({
  position: new Vector3(11.144790649414062, 0, 115.53800201416016),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine31.addComponentOrReplace(transform188)

const snowypine32 = new Entity('snowypine32')
engine.addEntity(snowypine32)
snowypine32.setParent(_scene)
snowypine32.addComponentOrReplace(gltfShape4)
const transform189 = new Transform({
  position: new Vector3(8.5, 0, 123),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine32.addComponentOrReplace(transform189)

const snowypine33 = new Entity('snowypine33')
engine.addEntity(snowypine33)
snowypine33.setParent(_scene)
snowypine33.addComponentOrReplace(gltfShape4)
const transform190 = new Transform({
  position: new Vector3(19.356847763061523, 0, 121.92333984375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine33.addComponentOrReplace(transform190)

const snowypine34 = new Entity('snowypine34')
engine.addEntity(snowypine34)
snowypine34.setParent(_scene)
snowypine34.addComponentOrReplace(gltfShape4)
const transform191 = new Transform({
  position: new Vector3(27.426734924316406, 0, 125.076904296875),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine34.addComponentOrReplace(transform191)

const snowypine35 = new Entity('snowypine35')
engine.addEntity(snowypine35)
snowypine35.setParent(_scene)
snowypine35.addComponentOrReplace(gltfShape4)
const transform192 = new Transform({
  position: new Vector3(31.56965446472168, 0, 124.93836212158203),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine35.addComponentOrReplace(transform192)

const snowypine36 = new Entity('snowypine36')
engine.addEntity(snowypine36)
snowypine36.setParent(_scene)
snowypine36.addComponentOrReplace(gltfShape4)
const transform193 = new Transform({
  position: new Vector3(38.232948303222656, 0, 119.82562255859375),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine36.addComponentOrReplace(transform193)

const snowypine37 = new Entity('snowypine37')
engine.addEntity(snowypine37)
snowypine37.setParent(_scene)
snowypine37.addComponentOrReplace(gltfShape4)
const transform194 = new Transform({
  position: new Vector3(47.84521484375, 0, 124.73650360107422),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine37.addComponentOrReplace(transform194)

const snowypine38 = new Entity('snowypine38')
engine.addEntity(snowypine38)
snowypine38.setParent(_scene)
snowypine38.addComponentOrReplace(gltfShape4)
const transform195 = new Transform({
  position: new Vector3(47.75213623046875, 0, 120.8200912475586),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine38.addComponentOrReplace(transform195)

const snowypine39 = new Entity('snowypine39')
engine.addEntity(snowypine39)
snowypine39.setParent(_scene)
snowypine39.addComponentOrReplace(gltfShape4)
const transform196 = new Transform({
  position: new Vector3(55.764366149902344, 0, 121.25206756591797),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine39.addComponentOrReplace(transform196)

const snowypine40 = new Entity('snowypine40')
engine.addEntity(snowypine40)
snowypine40.setParent(_scene)
snowypine40.addComponentOrReplace(gltfShape4)
const transform197 = new Transform({
  position: new Vector3(52.521484375, 0, 110.03189849853516),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine40.addComponentOrReplace(transform197)

const snowypine41 = new Entity('snowypine41')
engine.addEntity(snowypine41)
snowypine41.setParent(_scene)
snowypine41.addComponentOrReplace(gltfShape4)
const transform198 = new Transform({
  position: new Vector3(61, 0, 112),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine41.addComponentOrReplace(transform198)

const snowypine42 = new Entity('snowypine42')
engine.addEntity(snowypine42)
snowypine42.setParent(_scene)
snowypine42.addComponentOrReplace(gltfShape4)
const transform199 = new Transform({
  position: new Vector3(4.04056978225708, 0, 124.3961181640625),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine42.addComponentOrReplace(transform199)

const snowypine29 = new Entity('snowypine29')
engine.addEntity(snowypine29)
snowypine29.setParent(_scene)
snowypine29.addComponentOrReplace(gltfShape4)
const transform200 = new Transform({
  position: new Vector3(56.543636322021484, 0, 100.52243041992188),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine29.addComponentOrReplace(transform200)

const snowypine43 = new Entity('snowypine43')
engine.addEntity(snowypine43)
snowypine43.setParent(_scene)
snowypine43.addComponentOrReplace(gltfShape4)
const transform201 = new Transform({
  position: new Vector3(61.04374694824219, 0, 91.76203155517578),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine43.addComponentOrReplace(transform201)

const snowypine44 = new Entity('snowypine44')
engine.addEntity(snowypine44)
snowypine44.setParent(_scene)
snowypine44.addComponentOrReplace(gltfShape4)
const transform202 = new Transform({
  position: new Vector3(56.63365173339844, 0, 81.38304138183594),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine44.addComponentOrReplace(transform202)

const snowypine45 = new Entity('snowypine45')
engine.addEntity(snowypine45)
snowypine45.setParent(_scene)
snowypine45.addComponentOrReplace(gltfShape4)
const transform203 = new Transform({
  position: new Vector3(56.759315490722656, 0, 77.35112762451172),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine45.addComponentOrReplace(transform203)

const snowypine46 = new Entity('snowypine46')
engine.addEntity(snowypine46)
snowypine46.setParent(_scene)
snowypine46.addComponentOrReplace(gltfShape4)
const transform204 = new Transform({
  position: new Vector3(61.527320861816406, 0, 66.7696533203125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine46.addComponentOrReplace(transform204)

const snowypine47 = new Entity('snowypine47')
engine.addEntity(snowypine47)
snowypine47.setParent(_scene)
snowypine47.addComponentOrReplace(gltfShape4)
const transform205 = new Transform({
  position: new Vector3(55.21326446533203, 0, 62.265350341796875),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine47.addComponentOrReplace(transform205)

const snowypine48 = new Entity('snowypine48')
engine.addEntity(snowypine48)
snowypine48.setParent(_scene)
snowypine48.addComponentOrReplace(gltfShape4)
const transform206 = new Transform({
  position: new Vector3(61.55925750732422, 0, 42.65437316894531),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine48.addComponentOrReplace(transform206)

const snowypine49 = new Entity('snowypine49')
engine.addEntity(snowypine49)
snowypine49.setParent(_scene)
snowypine49.addComponentOrReplace(gltfShape4)
const transform207 = new Transform({
  position: new Vector3(53.671260833740234, 0, 50.509979248046875),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine49.addComponentOrReplace(transform207)

const snowypine50 = new Entity('snowypine50')
engine.addEntity(snowypine50)
snowypine50.setParent(_scene)
snowypine50.addComponentOrReplace(gltfShape4)
const transform208 = new Transform({
  position: new Vector3(53.199920654296875, 0, 54.79374694824219),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine50.addComponentOrReplace(transform208)

const tools = new Entity('tools')
engine.addEntity(tools)
tools.setParent(_scene)
const transform209 = new Transform({
  position: new Vector3(61.261959075927734, 0, 2.465458869934082),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
tools.addComponentOrReplace(transform209)

const clickArea = new Entity('clickArea')
engine.addEntity(clickArea)
clickArea.setParent(_scene)
const transform210 = new Transform({
  position: new Vector3(54.98988723754883, 0, 26.833465576171875),
  rotation: new Quaternion(-4.68017996489115e-17, 0.20253291726112366, -2.4143801624632033e-8, 0.9792755246162415),
  scale: new Vector3(6.792516708374023, 1.7850885391235352, 4.38268518447876)
})
clickArea.addComponentOrReplace(transform210)

const clickArea2 = new Entity('clickArea2')
engine.addEntity(clickArea2)
clickArea2.setParent(_scene)
const transform211 = new Transform({
  position: new Vector3(53.33430099487305, 0, 11.848644256591797),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.831273078918457, 0.9033002853393555, 2.000788688659668)
})
clickArea2.addComponentOrReplace(transform211)

const bsnowpile2 = new Entity('bsnowpile2')
engine.addEntity(bsnowpile2)
bsnowpile2.setParent(_scene)
bsnowpile2.addComponentOrReplace(gltfShape14)
const transform212 = new Transform({
  position: new Vector3(8.208179473876953, 0, 63.60141372680664),
  rotation: new Quaternion(-1.395363431428516e-16, 0.205867201089859, -2.4541277454659394e-8, 0.9785799384117126),
  scale: new Vector3(2.383544921875, 2.383544921875, 2.383544921875)
})
bsnowpile2.addComponentOrReplace(transform212)

const clickArea3 = new Entity('clickArea3')
engine.addEntity(clickArea3)
clickArea3.setParent(_scene)
const transform213 = new Transform({
  position: new Vector3(7.730373382568359, 0, 62.96282958984375),
  rotation: new Quaternion(-4.1611132117300395e-17, 0.2390213906764984, -2.8493568393628266e-8, 0.9710143804550171),
  scale: new Vector3(7.650385856628418, 2.1429572105407715, 4.740553855895996)
})
clickArea3.addComponentOrReplace(transform213)

const clickArea4 = new Entity('clickArea4')
engine.addEntity(clickArea4)
clickArea4.setParent(_scene)
const transform214 = new Transform({
  position: new Vector3(35.332679748535156, 0, 77.17903137207031),
  rotation: new Quaternion(-7.12638348872911e-18, -0.3811546564102173, 4.5437168694206775e-8, 0.9245113134384155),
  scale: new Vector3(1.4633337259292603, 1, 1.8458154201507568)
})
clickArea4.addComponentOrReplace(transform214)

const levelfinal = new Entity('levelfinal')
engine.addEntity(levelfinal)
levelfinal.setParent(_scene)
const transform215 = new Transform({
  position: new Vector3(29.174299240112305, 0, 52.83702087402344),
  rotation: new Quaternion(3.2752159444010987e-15, -0.723288357257843, 8.62226769982044e-8, 0.6905461549758911),
  scale: new Vector3(2.0722427368164062, 2.0722427368164062, 2.0722427368164062)
})
levelfinal.addComponentOrReplace(transform215)
const gltfShape25 = new GLTFShape("models/LevelFinal.glb")
gltfShape25.withCollisions = true
gltfShape25.visible = true
levelfinal.addComponentOrReplace(gltfShape25)

const clickArea5 = new Entity('clickArea5')
engine.addEntity(clickArea5)
clickArea5.setParent(_scene)
const transform216 = new Transform({
  position: new Vector3(43.18400192260742, 0.13188648223876953, 20.974040985107422),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.7935333251953125, 1.281796932220459, 0.7935333251953125)
})
clickArea5.addComponentOrReplace(transform216)

const clickArea7 = new Entity('clickArea7')
engine.addEntity(clickArea7)
clickArea7.setParent(_scene)
const transform217 = new Transform({
  position: new Vector3(43.2100715637207, 0.15067768096923828, 21.037843704223633),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.6403532028198242, 1.2974858283996582, 0.8756150007247925)
})
clickArea7.addComponentOrReplace(transform217)

const clickArea8 = new Entity('clickArea8')
engine.addEntity(clickArea8)
clickArea8.setParent(_scene)
const transform218 = new Transform({
  position: new Vector3(43.58182144165039, 0, 22.72570037841797),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.5060272216796875, 1.478144645690918, 0.5060272216796875)
})
clickArea8.addComponentOrReplace(transform218)

const pickaxefinal = new Entity('pickaxefinal')
engine.addEntity(pickaxefinal)
pickaxefinal.setParent(_scene)
const transform219 = new Transform({
  position: new Vector3(16.895999908447266, 0.2857785224914551, 114.61628723144531),
  rotation: new Quaternion(0.12059453874826431, -0.6200500130653381, 0.09722129255533218, -0.7691183090209961),
  scale: new Vector3(0.4335594177246094, 0.4335594177246094, 0.4335594177246094)
})
pickaxefinal.addComponentOrReplace(transform219)
const gltfShape26 = new GLTFShape("models/PickaxeFinal.glb")
gltfShape26.withCollisions = true
gltfShape26.visible = true
pickaxefinal.addComponentOrReplace(gltfShape26)

const clickArea6 = new Entity('clickArea6')
engine.addEntity(clickArea6)
clickArea6.setParent(_scene)
const transform220 = new Transform({
  position: new Vector3(17.012310028076172, 0, 114.3780517578125),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.2667732238769531, 2.3435628414154053, 1.2667732238769531)
})
clickArea6.addComponentOrReplace(transform220)

const indicatorArrow = new Entity('indicatorArrow')
engine.addEntity(indicatorArrow)
indicatorArrow.setParent(_scene)
const transform221 = new Transform({
  position: new Vector3(43.66538619995117, 1.7105311155319214, 22.85674285888672),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
indicatorArrow.addComponentOrReplace(transform221)

const indicatorArrow2 = new Entity('indicatorArrow2')
engine.addEntity(indicatorArrow2)
indicatorArrow2.setParent(_scene)
const transform222 = new Transform({
  position: new Vector3(54.559852600097656, 4.977104663848877, 27.094497680664062),
  rotation: new Quaternion(2.7673537827709374e-16, 0.5760374665260315, -6.866901003377279e-8, 0.8174233436584473),
  scale: new Vector3(3.3941192626953125, 3.3941192626953125, 3.3941192626953125)
})
indicatorArrow2.addComponentOrReplace(transform222)

const indicatorArrow3 = new Entity('indicatorArrow3')
engine.addEntity(indicatorArrow3)
indicatorArrow3.setParent(_scene)
const transform223 = new Transform({
  position: new Vector3(53.173954010009766, 1.5891375541687012, 11.938126564025879),
  rotation: new Quaternion(-1.3564833486001226e-15, -0.9919825196266174, 1.1825351009520091e-7, -0.12637567520141602),
  scale: new Vector3(3.3941192626953125, 3.3941192626953125, 3.3941192626953125)
})
indicatorArrow3.addComponentOrReplace(transform223)

const triggerArea = new Entity('triggerArea')
engine.addEntity(triggerArea)
triggerArea.setParent(_scene)
const transform224 = new Transform({
  position: new Vector3(12.852852821350098, 0, 84),
  rotation: new Quaternion(-1.3876591704648705e-17, 0.09193725138902664, -1.0959773533159023e-8, 0.9957647919654846),
  scale: new Vector3(5.652703762054443, 3.037778854370117, 3.037778854370117)
})
triggerArea.addComponentOrReplace(transform224)

const triggerArea2 = new Entity('triggerArea2')
engine.addEntity(triggerArea2)
triggerArea2.setParent(_scene)
const transform225 = new Transform({
  position: new Vector3(43.36298751831055, 0, 81.27819061279297),
  rotation: new Quaternion(3.4690949038849116e-16, -0.11118005216121674, 1.3253699471249547e-8, 0.9938003420829773),
  scale: new Vector3(7.054248809814453, 1, 1.000001311302185)
})
triggerArea2.addComponentOrReplace(transform225)

const present2 = new Entity('present2')
engine.addEntity(present2)
present2.setParent(_scene)
const transform226 = new Transform({
  position: new Vector3(49.860233306884766, 0.16185665130615234, 64.98104858398438),
  rotation: new Quaternion(7.249040840895903e-16, -0.44036099314689636, 5.249511403349061e-8, -0.8978208303451538),
  scale: new Vector3(1, 1, 1)
})
present2.addComponentOrReplace(transform226)
present2.addComponentOrReplace(gltfShape3)

const clickArea9 = new Entity('clickArea9')
engine.addEntity(clickArea9)
clickArea9.setParent(_scene)
const transform227 = new Transform({
  position: new Vector3(49.777610778808594, 0, 65.12980651855469),
  rotation: new Quaternion(-4.539462381363793e-16, -0.33623167872428894, 4.0081939545189016e-8, 0.9417793154716492),
  scale: new Vector3(1.3213337659835815, 1.190521240234375, 1.2975704669952393)
})
clickArea9.addComponentOrReplace(transform227)

const scoreboard = new Entity('scoreboard')
engine.addEntity(scoreboard)
scoreboard.setParent(_scene)
const transform228 = new Transform({
  position: new Vector3(28.81074333190918, 1.665825366973877, 13.616292953491211),
  rotation: new Quaternion(1.075537618358156e-14, 0.9774163961410522, -1.1651709996840509e-7, 0.21132278442382812),
  scale: new Vector3(1, 1, 1)
})
scoreboard.addComponentOrReplace(transform228)

const penguin8 = new Entity('penguin8')
engine.addEntity(penguin8)
penguin8.setParent(_scene)
penguin8.addComponentOrReplace(gltfShape8)
const transform229 = new Transform({
  position: new Vector3(27.407062530517578, 0.11815690994262695, 12.092422485351562),
  rotation: new Quaternion(-1.6659840418016894e-14, -0.5325719714164734, 6.348753345264413e-8, -0.8463847637176514),
  scale: new Vector3(0.44669342041015625, 0.44669342041015625, 0.44669342041015625)
})
penguin8.addComponentOrReplace(transform229)

const clickArea10 = new Entity('clickArea10')
engine.addEntity(clickArea10)
clickArea10.setParent(_scene)
const transform230 = new Transform({
  position: new Vector3(57.33704376220703, 5.217479705810547, 9.782393455505371),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.8124809265136719, 0.8124809265136719, 0.8124809265136719)
})
clickArea10.addComponentOrReplace(transform230)

const clickArea11 = new Entity('clickArea11')
engine.addEntity(clickArea11)
clickArea11.setParent(_scene)
const transform231 = new Transform({
  position: new Vector3(27.37830352783203, 0, 12.175800323486328),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.288717269897461, 1.288717269897461, 1.288717269897461)
})
clickArea11.addComponentOrReplace(transform231)

const triggerArea3 = new Entity('triggerArea3')
engine.addEntity(triggerArea3)
triggerArea3.setParent(_scene)
const transform232 = new Transform({
  position: new Vector3(51.87702560424805, 0, 78),
  rotation: new Quaternion(4.81136482787187e-15, -0.7498078346252441, 8.93840805815671e-8, 0.6616557240486145),
  scale: new Vector3(14.861485481262207, 1, 2.6988632678985596)
})
triggerArea3.addComponentOrReplace(transform232)

const triggerArea4 = new Entity('triggerArea4')
engine.addEntity(triggerArea4)
triggerArea4.setParent(_scene)
const transform233 = new Transform({
  position: new Vector3(49.300148010253906, 0, 76.76126098632812),
  rotation: new Quaternion(-2.80616374185921e-14, 0.13166210055351257, -1.5695373889457187e-8, -0.9912946820259094),
  scale: new Vector3(8.554411888122559, 0.9999998807907104, 2.4381613731384277)
})
triggerArea4.addComponentOrReplace(transform233)

const triggerArea5 = new Entity('triggerArea5')
engine.addEntity(triggerArea5)
triggerArea5.setParent(_scene)
const transform234 = new Transform({
  position: new Vector3(44.6663703918457, 0, 69.31967163085938),
  rotation: new Quaternion(-3.291712673378529e-14, -0.04146701470017433, 4.943227160936203e-9, -0.9991399049758911),
  scale: new Vector3(8.554411888122559, 0.9999998807907104, 2.4381613731384277)
})
triggerArea5.addComponentOrReplace(transform234)

const stickFenceEndModule = new Entity('stickFenceEndModule')
engine.addEntity(stickFenceEndModule)
stickFenceEndModule.setParent(_scene)
const transform235 = new Transform({
  position: new Vector3(46.12070846557617, 9.849142074584961, 111.65301513671875),
  rotation: new Quaternion(-0.729859471321106, -0.013038991019129753, -0.013926725834608078, 0.6833310127258301),
  scale: new Vector3(9.2295560836792, 4.16900634765625, 5.349931240081787)
})
stickFenceEndModule.addComponentOrReplace(transform235)
const gltfShape27 = new GLTFShape("models/FenceSticksEnd_01/FenceSticksEnd_01.glb")
gltfShape27.withCollisions = true
gltfShape27.visible = true
stickFenceEndModule.addComponentOrReplace(gltfShape27)

const stickFenceEndModule3 = new Entity('stickFenceEndModule3')
engine.addEntity(stickFenceEndModule3)
stickFenceEndModule3.setParent(_scene)
stickFenceEndModule3.addComponentOrReplace(gltfShape27)
const transform236 = new Transform({
  position: new Vector3(42.46216583251953, 9.430365562438965, 114.29072570800781),
  rotation: new Quaternion(-0.7232570052146912, 0.09262789785861969, 0.0989350751042366, 0.6771494150161743),
  scale: new Vector3(4.16900634765625, 4.16900634765625, 4.16900634765625)
})
stickFenceEndModule3.addComponentOrReplace(transform236)

const stickFenceEndModule4 = new Entity('stickFenceEndModule4')
engine.addEntity(stickFenceEndModule4)
stickFenceEndModule4.setParent(_scene)
stickFenceEndModule4.addComponentOrReplace(gltfShape27)
const transform237 = new Transform({
  position: new Vector3(38.409610748291016, 9.430365562438965, 117.85755157470703),
  rotation: new Quaternion(-0.7117877006530762, 0.15168128907680511, 0.16200941801071167, 0.6664113402366638),
  scale: new Vector3(4.16900634765625, 4.16900634765625, 4.16900634765625)
})
stickFenceEndModule4.addComponentOrReplace(transform237)

const stickFenceEndModule2 = new Entity('stickFenceEndModule2')
engine.addEntity(stickFenceEndModule2)
stickFenceEndModule2.setParent(_scene)
stickFenceEndModule2.addComponentOrReplace(gltfShape27)
const transform238 = new Transform({
  position: new Vector3(47.62564468383789, 9.849142074584961, 111.41018676757812),
  rotation: new Quaternion(-0.7295146584510803, 0.02471935749053955, 0.026402605697512627, 0.6830081939697266),
  scale: new Vector3(9.2295560836792, 4.16900634765625, 5.349931240081787)
})
stickFenceEndModule2.addComponentOrReplace(transform238)

const stickFenceEndModule5 = new Entity('stickFenceEndModule5')
engine.addEntity(stickFenceEndModule5)
stickFenceEndModule5.setParent(_scene)
stickFenceEndModule5.addComponentOrReplace(gltfShape27)
const transform239 = new Transform({
  position: new Vector3(33.564674377441406, 9.430365562438965, 119.41424560546875),
  rotation: new Quaternion(-0.7299389839172363, 0.008262705989181995, 0.008825385943055153, 0.6834055185317993),
  scale: new Vector3(4.16900634765625, 4.16900634765625, 4.16900634765625)
})
stickFenceEndModule5.addComponentOrReplace(transform239)

const stickFenceEndModule6 = new Entity('stickFenceEndModule6')
engine.addEntity(stickFenceEndModule6)
stickFenceEndModule6.setParent(_scene)
stickFenceEndModule6.addComponentOrReplace(gltfShape27)
const transform240 = new Transform({
  position: new Vector3(28.894121170043945, 9.430365562438965, 119.59424591064453),
  rotation: new Quaternion(-0.7299389839172363, 0.008262705989181995, 0.008825385943055153, 0.6834055185317993),
  scale: new Vector3(4.16900634765625, 4.16900634765625, 4.16900634765625)
})
stickFenceEndModule6.addComponentOrReplace(transform240)

const stickFenceEndModule7 = new Entity('stickFenceEndModule7')
engine.addEntity(stickFenceEndModule7)
stickFenceEndModule7.setParent(_scene)
stickFenceEndModule7.addComponentOrReplace(gltfShape27)
const transform241 = new Transform({
  position: new Vector3(23.15410614013672, 10.166111946105957, 118.76917266845703),
  rotation: new Quaternion(-0.7295146584510803, 0.02471935749053955, 0.026402605697512627, 0.6830081939697266),
  scale: new Vector3(9.2295560836792, 4.16900634765625, 5.349931240081787)
})
stickFenceEndModule7.addComponentOrReplace(transform241)

const stickFenceEndModule8 = new Entity('stickFenceEndModule8')
engine.addEntity(stickFenceEndModule8)
stickFenceEndModule8.setParent(_scene)
stickFenceEndModule8.addComponentOrReplace(gltfShape27)
const transform242 = new Transform({
  position: new Vector3(21.62411117553711, 10.166111946105957, 118.76917266845703),
  rotation: new Quaternion(-0.7295146584510803, 0.02471935749053955, 0.026402605697512627, 0.6830081939697266),
  scale: new Vector3(9.2295560836792, 4.16900634765625, 5.349931240081787)
})
stickFenceEndModule8.addComponentOrReplace(transform242)

const stickFenceEndModule9 = new Entity('stickFenceEndModule9')
engine.addEntity(stickFenceEndModule9)
stickFenceEndModule9.setParent(_scene)
stickFenceEndModule9.addComponentOrReplace(gltfShape27)
const transform243 = new Transform({
  position: new Vector3(3.4454269409179688, 7.127509117126465, 94.29490661621094),
  rotation: new Quaternion(-0.5411783456802368, -0.45868119597435, -0.48991283774375916, 0.5066783428192139),
  scale: new Vector3(9.2295560836792, 4.16900634765625, 5.349931240081787)
})
stickFenceEndModule9.addComponentOrReplace(transform243)

const stickFenceEndModule10 = new Entity('stickFenceEndModule10')
engine.addEntity(stickFenceEndModule10)
stickFenceEndModule10.setParent(_scene)
stickFenceEndModule10.addComponentOrReplace(gltfShape27)
const transform244 = new Transform({
  position: new Vector3(5.4841766357421875, 7.127509117126465, 89.79350280761719),
  rotation: new Quaternion(-0.5411783456802368, -0.45868119597435, -0.48991283774375916, 0.5066783428192139),
  scale: new Vector3(2.0596020221710205, 1.6901878118515015, 3.2960870265960693)
})
stickFenceEndModule10.addComponentOrReplace(transform244)

const stickFenceEndModule11 = new Entity('stickFenceEndModule11')
engine.addEntity(stickFenceEndModule11)
stickFenceEndModule11.setParent(_scene)
stickFenceEndModule11.addComponentOrReplace(gltfShape27)
const transform245 = new Transform({
  position: new Vector3(4.879480361938477, 7.028484344482422, 85.36956787109375),
  rotation: new Quaternion(-0.5411783456802368, -0.45868119597435, -0.48991283774375916, 0.5066783428192139),
  scale: new Vector3(2.0596020221710205, 1.6901878118515015, 3.2960870265960693)
})
stickFenceEndModule11.addComponentOrReplace(transform245)

const stickFenceEndModule12 = new Entity('stickFenceEndModule12')
engine.addEntity(stickFenceEndModule12)
stickFenceEndModule12.setParent(_scene)
stickFenceEndModule12.addComponentOrReplace(gltfShape27)
const transform246 = new Transform({
  position: new Vector3(5.461252212524414, 7.997441291809082, 81.28237915039062),
  rotation: new Quaternion(-0.5411783456802368, -0.45868119597435, -0.48991283774375916, 0.5066783428192139),
  scale: new Vector3(2.0596020221710205, 1.6901878118515015, 3.2960870265960693)
})
stickFenceEndModule12.addComponentOrReplace(transform246)

const stickFenceEndModule13 = new Entity('stickFenceEndModule13')
engine.addEntity(stickFenceEndModule13)
stickFenceEndModule13.setParent(_scene)
stickFenceEndModule13.addComponentOrReplace(gltfShape27)
const transform247 = new Transform({
  position: new Vector3(5.826576232910156, 8.774484634399414, 76.83695983886719),
  rotation: new Quaternion(-0.5411783456802368, -0.45868119597435, -0.48991283774375916, 0.5066783428192139),
  scale: new Vector3(2.0596020221710205, 1.6901878118515015, 3.2960870265960693)
})
stickFenceEndModule13.addComponentOrReplace(transform247)

const present3 = new Entity('present3')
engine.addEntity(present3)
present3.setParent(_scene)
const transform248 = new Transform({
  position: new Vector3(10.582779884338379, 12.621938705444336, 83.0438461303711),
  rotation: new Quaternion(0, 0.17648166418075562, -2.1038253805727436e-8, 0.9843039512634277),
  scale: new Vector3(1, 1, 1)
})
present3.addComponentOrReplace(transform248)
present3.addComponentOrReplace(gltfShape3)

const clickArea12 = new Entity('clickArea12')
engine.addEntity(clickArea12)
clickArea12.setParent(_scene)
const transform249 = new Transform({
  position: new Vector3(10.64799690246582, 12.421150207519531, 83.01563262939453),
  rotation: new Quaternion(1.3903053212444276e-17, 0.23012661933898926, -2.7433225469053468e-8, 0.9731607437133789),
  scale: new Vector3(1.3367605209350586, 1.3367605209350586, 1.3367605209350586)
})
clickArea12.addComponentOrReplace(transform249)

const penguin9 = new Entity('penguin9')
engine.addEntity(penguin9)
penguin9.setParent(_scene)
penguin9.addComponentOrReplace(gltfShape8)
const transform250 = new Transform({
  position: new Vector3(8.084550857543945, 8.58030891418457, 102.47283935546875),
  rotation: new Quaternion(1.1818149269534478e-14, -0.16771265864372253, 1.9992929978229768e-8, 0.9858359694480896),
  scale: new Vector3(0.44669342041015625, 0.44669342041015625, 0.44669342041015625)
})
penguin9.addComponentOrReplace(transform250)

const clickArea13 = new Entity('clickArea13')
engine.addEntity(clickArea13)
clickArea13.setParent(_scene)
const transform251 = new Transform({
  position: new Vector3(8.168038368225098, 8.58139419555664, 102.41771697998047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1.2213804721832275, 1)
})
clickArea13.addComponentOrReplace(transform251)

const unlitTorch = new Entity('unlitTorch')
engine.addEntity(unlitTorch)
unlitTorch.setParent(_scene)
const transform252 = new Transform({
  position: new Vector3(33.5, 0.10485732555389404, 86.11568450927734),
  rotation: new Quaternion(-0.28608018159866333, -1.0062223341278034e-16, 3.410341165022146e-8, 0.9582057595252991),
  scale: new Vector3(0.0919647216796875, 0.0919647216796875, 0.0919647216796875)
})
unlitTorch.addComponentOrReplace(transform252)
const gltfShape28 = new GLTFShape("models/unlit torch.glb")
gltfShape28.withCollisions = true
gltfShape28.visible = true
unlitTorch.addComponentOrReplace(gltfShape28)

const skull5 = new Entity('skull5')
engine.addEntity(skull5)
skull5.setParent(_scene)
const transform253 = new Transform({
  position: new Vector3(34.5997314453125, 0, 85.04940795898438),
  rotation: new Quaternion(-1.561089662723556e-17, -0.06391410529613495, 7.619153308269233e-9, 0.9979554414749146),
  scale: new Vector3(1, 1, 1)
})
skull5.addComponentOrReplace(transform253)
skull5.addComponentOrReplace(gltfShape24)

const bigBone32 = new Entity('bigBone32')
engine.addEntity(bigBone32)
bigBone32.setParent(_scene)
const transform254 = new Transform({
  position: new Vector3(33.115135192871094, 0.06511819362640381, 86.1611557006836),
  rotation: new Quaternion(4.872330977162564e-16, -0.24186670780181885, 2.8832751297613868e-8, 0.9703095555305481),
  scale: new Vector3(1, 1, 1)
})
bigBone32.addComponentOrReplace(transform254)
bigBone32.addComponentOrReplace(gltfShape22)

const bigBone33 = new Entity('bigBone33')
engine.addEntity(bigBone33)
bigBone33.setParent(_scene)
bigBone33.addComponentOrReplace(gltfShape22)
const transform255 = new Transform({
  position: new Vector3(33.2021484375, 0.12871360778808594, 86.13032531738281),
  rotation: new Quaternion(0.09660838544368744, 0.14265500009059906, 0.01399227511137724, 0.9849470257759094),
  scale: new Vector3(1, 1, 1)
})
bigBone33.addComponentOrReplace(transform255)

const beachBones5 = new Entity('beachBones5')
engine.addEntity(beachBones5)
beachBones5.setParent(_scene)
const transform256 = new Transform({
  position: new Vector3(34.215370178222656, 0.0808262825012207, 86.33869171142578),
  rotation: new Quaternion(-4.510022295444092e-17, -0.13371483981609344, 1.5940049280516178e-8, 0.9910199046134949),
  scale: new Vector3(1, 1, 1)
})
beachBones5.addComponentOrReplace(transform256)
beachBones5.addComponentOrReplace(gltfShape23)

const clickArea14 = new Entity('clickArea14')
engine.addEntity(clickArea14)
clickArea14.setParent(_scene)
const transform257 = new Transform({
  position: new Vector3(33.543155670166016, 0, 85.79780578613281),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
clickArea14.addComponentOrReplace(transform257)

const clickArea15 = new Entity('clickArea15')
engine.addEntity(clickArea15)
clickArea15.setParent(_scene)
const transform258 = new Transform({
  position: new Vector3(29.86956024169922, 0, 42.51096725463867),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.1043777465820312, 1.1043777465820312, 1.1043777465820312)
})
clickArea15.addComponentOrReplace(transform258)

const clickArea16 = new Entity('clickArea16')
engine.addEntity(clickArea16)
clickArea16.setParent(_scene)
const transform259 = new Transform({
  position: new Vector3(25.344099044799805, 0, 25.154333114624023),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(2.5831470489501953, 2.5831470489501953, 2.5831470489501953)
})
clickArea16.addComponentOrReplace(transform259)

const clickArea17 = new Entity('clickArea17')
engine.addEntity(clickArea17)
clickArea17.setParent(_scene)
const transform260 = new Transform({
  position: new Vector3(25.385883331298828, 0.2080521583557129, 24.944055557250977),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.4388236999511719, 1.4388236999511719, 1.4388236999511719)
})
clickArea17.addComponentOrReplace(transform260)

const present4 = new Entity('present4')
engine.addEntity(present4)
present4.setParent(_scene)
const transform261 = new Transform({
  position: new Vector3(25.36998748779297, 0.6097564697265625, 24.972454071044922),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
present4.addComponentOrReplace(transform261)
present4.addComponentOrReplace(gltfShape3)

const treeStump = new Entity('treeStump')
engine.addEntity(treeStump)
treeStump.setParent(_scene)
const transform262 = new Transform({
  position: new Vector3(51.80756378173828, 0, 116.30598449707031),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(3.3443336486816406, 3.3443336486816406, 3.3443336486816406)
})
treeStump.addComponentOrReplace(transform262)
const gltfShape29 = new GLTFShape("models/TreeStump_01/TreeStump_01.glb")
gltfShape29.withCollisions = true
gltfShape29.visible = true
treeStump.addComponentOrReplace(gltfShape29)

const triggerArea6 = new Entity('triggerArea6')
engine.addEntity(triggerArea6)
triggerArea6.setParent(_scene)
const transform263 = new Transform({
  position: new Vector3(51.51019287109375, 0, 119.23062133789062),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(18.81026840209961, 2.4771673679351807, 14.111351013183594)
})
triggerArea6.addComponentOrReplace(transform263)

const snowypine19 = new Entity('snowypine19')
engine.addEntity(snowypine19)
snowypine19.setParent(_scene)
snowypine19.addComponentOrReplace(gltfShape4)
const transform264 = new Transform({
  position: new Vector3(52.220558166503906, 0, 123.09794616699219),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine19.addComponentOrReplace(transform264)

const snowypine20 = new Entity('snowypine20')
engine.addEntity(snowypine20)
snowypine20.setParent(_scene)
snowypine20.addComponentOrReplace(gltfShape4)
const transform265 = new Transform({
  position: new Vector3(56.35917282104492, 0, 124.4505844116211),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine20.addComponentOrReplace(transform265)

const snowypine51 = new Entity('snowypine51')
engine.addEntity(snowypine51)
snowypine51.setParent(_scene)
snowypine51.addComponentOrReplace(gltfShape4)
const transform266 = new Transform({
  position: new Vector3(59.852630615234375, 0, 121.26627349853516),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine51.addComponentOrReplace(transform266)

const snowypine52 = new Entity('snowypine52')
engine.addEntity(snowypine52)
snowypine52.setParent(_scene)
snowypine52.addComponentOrReplace(gltfShape4)
const transform267 = new Transform({
  position: new Vector3(61.489322662353516, 0, 116.76637268066406),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine52.addComponentOrReplace(transform267)

const snowypine53 = new Entity('snowypine53')
engine.addEntity(snowypine53)
snowypine53.setParent(_scene)
snowypine53.addComponentOrReplace(gltfShape4)
const transform268 = new Transform({
  position: new Vector3(58.37574005126953, 0, 116.86307525634766),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine53.addComponentOrReplace(transform268)

const snowypine54 = new Entity('snowypine54')
engine.addEntity(snowypine54)
snowypine54.setParent(_scene)
snowypine54.addComponentOrReplace(gltfShape4)
const transform269 = new Transform({
  position: new Vector3(61.193519592285156, 0, 124.15287780761719),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.6110725402832031, 1.6110725402832031, 1.6110725402832031)
})
snowypine54.addComponentOrReplace(transform269)

const sleepypenguin = new Entity('sleepypenguin')
engine.addEntity(sleepypenguin)
sleepypenguin.setParent(_scene)
const transform270 = new Transform({
  position: new Vector3(11.369773864746094, 0, 47.754547119140625),
  rotation: new Quaternion(-0.26836833357810974, -0.9145567417144775, 0.17479877173900604, 0.2470017969608307),
  scale: new Vector3(0.5150175094604492, 0.5150175094604492, 0.5150175094604492)
})
sleepypenguin.addComponentOrReplace(transform270)
const gltfShape30 = new GLTFShape("models/SleepyPenguin.glb")
gltfShape30.withCollisions = true
gltfShape30.visible = true
sleepypenguin.addComponentOrReplace(gltfShape30)

const newspaper = new Entity('newspaper')
engine.addEntity(newspaper)
newspaper.setParent(_scene)
const transform271 = new Transform({
  position: new Vector3(11.628521919250488, 1.2756892442703247, 47.35029983520508),
  rotation: new Quaternion(0.448741614818573, 0.22580307722091675, -0.8557244539260864, 0.12401454895734787),
  scale: new Vector3(1, 1, 1)
})
newspaper.addComponentOrReplace(transform271)
const gltfShape31 = new GLTFShape("models/newspaper.glb")
gltfShape31.withCollisions = true
gltfShape31.visible = true
newspaper.addComponentOrReplace(gltfShape31)

const clickArea18 = new Entity('clickArea18')
engine.addEntity(clickArea18)
clickArea18.setParent(_scene)
const transform272 = new Transform({
  position: new Vector3(11.573334693908691, 0, 47.55885696411133),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.7252988815307617, 1.7252988815307617, 1.7252988815307617)
})
clickArea18.addComponentOrReplace(transform272)

const clickArea19 = new Entity('clickArea19')
engine.addEntity(clickArea19)
clickArea19.setParent(_scene)
const transform273 = new Transform({
  position: new Vector3(11.776453018188477, 0, 47.5181999206543),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1.382014274597168, 1.382014274597168, 1.382014274597168)
})
clickArea19.addComponentOrReplace(transform273)

const clickArea20 = new Entity('clickArea20')
engine.addEntity(clickArea20)
clickArea20.setParent(_scene)
const transform274 = new Transform({
  position: new Vector3(51.97334671020508, 1.0520925521850586, 116.58970642089844),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.10286331176757812, 0.10286331176757812, 0.10286331176757812)
})
clickArea20.addComponentOrReplace(transform274)

const present5 = new Entity('present5')
engine.addEntity(present5)
present5.setParent(_scene)
const transform275 = new Transform({
  position: new Vector3(52.039913177490234, 0.6037859916687012, 116.2567138671875),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(0.025646209716796875, 0.025646209716796875, 0.025646209716796875)
})
present5.addComponentOrReplace(transform275)
present5.addComponentOrReplace(gltfShape3)

const fallingsnow = new Entity('fallingsnow')
engine.addEntity(fallingsnow)
fallingsnow.setParent(_scene)
const transform276 = new Transform({
  position: new Vector3(45.0366325378418, 0, 17.870615005493164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow.addComponentOrReplace(transform276)
const gltfShape32 = new GLTFShape("models/FallingSnow.glb")
gltfShape32.withCollisions = true
gltfShape32.visible = true
fallingsnow.addComponentOrReplace(gltfShape32)

const fallingsnow2 = new Entity('fallingsnow2')
engine.addEntity(fallingsnow2)
fallingsnow2.setParent(_scene)
fallingsnow2.addComponentOrReplace(gltfShape32)
const transform277 = new Transform({
  position: new Vector3(32.09907150268555, 0, 17.870615005493164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow2.addComponentOrReplace(transform277)

const fallingsnow3 = new Entity('fallingsnow3')
engine.addEntity(fallingsnow3)
fallingsnow3.setParent(_scene)
fallingsnow3.addComponentOrReplace(gltfShape32)
const transform278 = new Transform({
  position: new Vector3(17.101417541503906, 0, 17.870615005493164),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow3.addComponentOrReplace(transform278)

const fallingsnow4 = new Entity('fallingsnow4')
engine.addEntity(fallingsnow4)
fallingsnow4.setParent(_scene)
fallingsnow4.addComponentOrReplace(gltfShape32)
const transform279 = new Transform({
  position: new Vector3(17.120189666748047, 0, 34.854427337646484),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow4.addComponentOrReplace(transform279)

const fallingsnow5 = new Entity('fallingsnow5')
engine.addEntity(fallingsnow5)
fallingsnow5.setParent(_scene)
fallingsnow5.addComponentOrReplace(gltfShape32)
const transform280 = new Transform({
  position: new Vector3(30.30870819091797, 0, 34.854427337646484),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow5.addComponentOrReplace(transform280)

const fallingsnow6 = new Entity('fallingsnow6')
engine.addEntity(fallingsnow6)
fallingsnow6.setParent(_scene)
fallingsnow6.addComponentOrReplace(gltfShape32)
const transform281 = new Transform({
  position: new Vector3(45.1413459777832, 0, 34.854427337646484),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow6.addComponentOrReplace(transform281)

const fallingsnow7 = new Entity('fallingsnow7')
engine.addEntity(fallingsnow7)
fallingsnow7.setParent(_scene)
fallingsnow7.addComponentOrReplace(gltfShape32)
const transform282 = new Transform({
  position: new Vector3(45.1413459777832, 0, 48.835514068603516),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow7.addComponentOrReplace(transform282)

const fallingsnow8 = new Entity('fallingsnow8')
engine.addEntity(fallingsnow8)
fallingsnow8.setParent(_scene)
fallingsnow8.addComponentOrReplace(gltfShape32)
const transform283 = new Transform({
  position: new Vector3(31.18466567993164, 0, 48.835514068603516),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow8.addComponentOrReplace(transform283)

const fallingsnow9 = new Entity('fallingsnow9')
engine.addEntity(fallingsnow9)
fallingsnow9.setParent(_scene)
fallingsnow9.addComponentOrReplace(gltfShape32)
const transform284 = new Transform({
  position: new Vector3(17.334903717041016, 0, 48.835514068603516),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow9.addComponentOrReplace(transform284)

const fallingsnow10 = new Entity('fallingsnow10')
engine.addEntity(fallingsnow10)
fallingsnow10.setParent(_scene)
fallingsnow10.addComponentOrReplace(gltfShape32)
const transform285 = new Transform({
  position: new Vector3(17.334903717041016, 0, 64.65486145019531),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow10.addComponentOrReplace(transform285)

const fallingsnow11 = new Entity('fallingsnow11')
engine.addEntity(fallingsnow11)
fallingsnow11.setParent(_scene)
fallingsnow11.addComponentOrReplace(gltfShape32)
const transform286 = new Transform({
  position: new Vector3(29.597679138183594, 0, 64.65486145019531),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow11.addComponentOrReplace(transform286)

const fallingsnow12 = new Entity('fallingsnow12')
engine.addEntity(fallingsnow12)
fallingsnow12.setParent(_scene)
fallingsnow12.addComponentOrReplace(gltfShape32)
const transform287 = new Transform({
  position: new Vector3(44.818538665771484, 0, 64.65486145019531),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow12.addComponentOrReplace(transform287)

const fallingsnow13 = new Entity('fallingsnow13')
engine.addEntity(fallingsnow13)
fallingsnow13.setParent(_scene)
fallingsnow13.addComponentOrReplace(gltfShape32)
const transform288 = new Transform({
  position: new Vector3(44.92255783081055, 0, 78.92518615722656),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow13.addComponentOrReplace(transform288)

const fallingsnow14 = new Entity('fallingsnow14')
engine.addEntity(fallingsnow14)
fallingsnow14.setParent(_scene)
fallingsnow14.addComponentOrReplace(gltfShape32)
const transform289 = new Transform({
  position: new Vector3(44.92255783081055, 0, 95.66444396972656),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow14.addComponentOrReplace(transform289)

const fallingsnow15 = new Entity('fallingsnow15')
engine.addEntity(fallingsnow15)
fallingsnow15.setParent(_scene)
fallingsnow15.addComponentOrReplace(gltfShape32)
const transform290 = new Transform({
  position: new Vector3(44.92255783081055, 0, 109.69261932373047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow15.addComponentOrReplace(transform290)

const fallingsnow16 = new Entity('fallingsnow16')
engine.addEntity(fallingsnow16)
fallingsnow16.setParent(_scene)
fallingsnow16.addComponentOrReplace(gltfShape32)
const transform291 = new Transform({
  position: new Vector3(31.188007354736328, 0, 95.66444396972656),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow16.addComponentOrReplace(transform291)

const fallingsnow17 = new Entity('fallingsnow17')
engine.addEntity(fallingsnow17)
fallingsnow17.setParent(_scene)
fallingsnow17.addComponentOrReplace(gltfShape32)
const transform292 = new Transform({
  position: new Vector3(17.148941040039062, 0, 95.66444396972656),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow17.addComponentOrReplace(transform292)

const fallingsnow18 = new Entity('fallingsnow18')
engine.addEntity(fallingsnow18)
fallingsnow18.setParent(_scene)
fallingsnow18.addComponentOrReplace(gltfShape32)
const transform293 = new Transform({
  position: new Vector3(34.8164176940918, 0, 109.69261932373047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow18.addComponentOrReplace(transform293)

const fallingsnow19 = new Entity('fallingsnow19')
engine.addEntity(fallingsnow19)
fallingsnow19.setParent(_scene)
fallingsnow19.addComponentOrReplace(gltfShape32)
const transform294 = new Transform({
  position: new Vector3(17.989971160888672, 0, 109.69261932373047),
  rotation: new Quaternion(0, 0, 0, 1),
  scale: new Vector3(1, 1, 1)
})
fallingsnow19.addComponentOrReplace(transform294)

const channelId = Math.random().toString(16).slice(2)
const channelBus = new MessageBus()
const inventory = createInventory(UICanvas, UIContainerStack, UIImage)
const options = { inventory }

const script1 = new Script1()
const script2 = new Script2()
const script3 = new Script3()
const script4 = new Script4()
const script5 = new Script5()
script1.init(options)
script2.init(options)
script3.init(options)
script4.init(options)
script5.init(options)
script1.spawn(tools, {}, createChannel(channelId, tools, channelBus))
script2.spawn(clickArea, {"enabled":false,"onClick":[{"entityName":"clickArea2","actionId":"enable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"bsnowpile","x":0.6,"y":0.6,"z":0.6,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"clickArea3","actionId":"disable","values":{}},{"entityName":"clickArea","actionId":"disable","values":{}},{"entityName":"indicatorArrow2","actionId":"deactivate","values":{}},{"entityName":"indicatorArrow3","actionId":"activate","values":{}},{"entityName":"tools","actionId":"print","values":{"message":"Dump the snow to reach the present.","duration":5,"multiplayer":false}}]}}]}}]}, createChannel(channelId, clickArea, channelBus))
script2.spawn(clickArea2, {"enabled":false,"onClick":[{"entityName":"tools","actionId":"scale","values":{"target":"snowpile","x":4,"y":4,"z":4,"speed":10,"onComplete":[{"entityName":"clickArea3","actionId":"enable","values":{}},{"entityName":"clickArea4","actionId":"disable","values":{}},{"entityName":"indicatorArrow3","actionId":"deactivate","values":{}}]}}]}, createChannel(channelId, clickArea2, channelBus))
script2.spawn(clickArea3, {"enabled":false,"onClick":[{"entityName":"clickArea4","actionId":"enable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"bsnowpile2","x":0.6,"y":0.6,"z":0.6,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea3","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea9","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"clickArea3","actionId":"disable","values":{}},{"entityName":"clickArea9","actionId":"disable","values":{}},{"entityName":"clickArea","actionId":"disable","values":{}}]}}]}}]}},{"entityName":"tools","actionId":"scale","values":{"target":"clickArea","x":0.5,"y":0.5,"z":0.5,"speed":10,"onComplete":[]}}]}, createChannel(channelId, clickArea3, channelBus))
script2.spawn(clickArea4, {"enabled":false,"onClick":[{"entityName":"tools","actionId":"scale","values":{"target":"snowpile2","x":4,"y":7,"z":5,"speed":10,"onComplete":[{"entityName":"clickArea","actionId":"enable","values":{}}]}}]}, createChannel(channelId, clickArea4, channelBus))
script2.spawn(clickArea5, {"enabled":true,"onClick":[{"entityName":"tools","actionId":"print","values":{"message":"\"Man, this shovel isn't working on these blue rocks.\"","duration":3,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":3,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"Bring me a pickaxe and I'll trade you my MIGHTY SHOVEL.\"","duration":5,"multiplayer":false}},{"entityName":"clickArea6","actionId":"enable","values":{}}]}}]}, createChannel(channelId, clickArea5, channelBus))
script2.spawn(clickArea7, {"enabled":false,"onClick":[{"entityName":"tools","actionId":"print","values":{"message":"Thank You!  Take my special shovel.","duration":2,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":3,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"It can shovel snow like nobody's business.\"","duration":3,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":3,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"Try it on the big snowpile over there.\"","duration":5,"multiplayer":false}},{"entityName":"indicatorArrow","actionId":"activate","values":{}}]}}]}},{"entityName":"clickArea8","actionId":"enable","values":{}}]}, createChannel(channelId, clickArea7, channelBus))
script2.spawn(clickArea8, {"enabled":false,"onClick":[{"entityName":"tools","actionId":"scale","values":{"target":"shovel","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea8","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"print","values":{"message":"You pick up the shovel.","duration":5,"multiplayer":false}},{"entityName":"clickArea","actionId":"enable","values":{}},{"entityName":"clickArea3","actionId":"enable","values":{}},{"entityName":"indicatorArrow","actionId":"deactivate","values":{}},{"entityName":"tools","actionId":"print","values":{"message":"Click the snowpile under the arrow","duration":10,"multiplayer":false}},{"entityName":"indicatorArrow2","actionId":"activate","values":{}}]}}]}}]}, createChannel(channelId, clickArea8, channelBus))
script2.spawn(clickArea6, {"enabled":false,"onClick":[{"entityName":"tools","actionId":"scale","values":{"target":"pickaxefinal","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea6","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"print","values":{"message":"You pick up the pickaxe.","duration":5,"multiplayer":false}},{"entityName":"clickArea5","actionId":"disable","values":{}},{"entityName":"clickArea7","actionId":"enable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"clickArea5","x":0,"y":0,"z":0,"speed":10,"onComplete":[]}}]}}]}}]}, createChannel(channelId, clickArea6, channelBus))
script3.spawn(indicatorArrow, {"active":false}, createChannel(channelId, indicatorArrow, channelBus))
script3.spawn(indicatorArrow2, {"active":false}, createChannel(channelId, indicatorArrow2, channelBus))
script3.spawn(indicatorArrow3, {"active":false}, createChannel(channelId, indicatorArrow3, channelBus))
script4.spawn(triggerArea, {"enabled":true,"onEnter":[{"entityName":"tools","actionId":"print","values":{"message":"Loud snoring echoes from the cave.","duration":5,"multiplayer":false}},{"entityName":"clickArea9","actionId":"enable","values":{}}],"onLeave":[{"entityName":"clickArea9","actionId":"enable","values":{}}]}, createChannel(channelId, triggerArea, channelBus))
script4.spawn(triggerArea2, {"enabled":true,"onEnter":[{"entityName":"clickArea9","actionId":"disable","values":{}},{"entityName":"tools","actionId":"print","values":{"message":"CRACK","duration":1,"multiplayer":false}}],"onLeave":[{"entityName":"tools","actionId":"print","values":{"message":"RUN FOREST RUN","duration":5,"multiplayer":false}}]}, createChannel(channelId, triggerArea2, channelBus))
script2.spawn(clickArea9, {"enabled":true,"onClick":[{"entityName":"clickArea9","actionId":"disable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"present2","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea9","x":0,"y":0,"z":0,"speed":10,"onComplete":[]}}]}},{"entityName":"scoreboard","actionId":"increase","values":{}}]}, createChannel(channelId, clickArea9, channelBus))
script5.spawn(scoreboard, {"initialVal":0,"threshold":5,"enabled":true,"onThreshold":[{"entityName":"tools","actionId":"move","values":{"x":0,"y":0,"z":0,"speed":10,"relative":true,"onComplete":[]}}]}, createChannel(channelId, scoreboard, channelBus))
script2.spawn(clickArea10, {"enabled":true,"onClick":[{"entityName":"scoreboard","actionId":"increase","values":{}},{"entityName":"clickArea10","actionId":"disable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"present","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea10","x":0,"y":0,"z":0,"speed":10,"onComplete":[]}}]}}]}, createChannel(channelId, clickArea10, channelBus))
script2.spawn(clickArea11, {"enabled":true,"onClick":[{"entityName":"tools","actionId":"print","values":{"message":"\"You can keep track of how many presents you find on this scoreboard.\"","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"print","values":{"message":"\"There are 5 presents in total.\"","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea11, channelBus))
script4.spawn(triggerArea3, {"enabled":true,"onEnter":[{"entityName":"clickArea9","actionId":"disable","values":{}},{"entityName":"tools","actionId":"print","values":{"message":"CRUNCH","duration":1,"multiplayer":false}}],"onLeave":[{"entityName":"tools","actionId":"print","values":{"message":"IT'S NOT YOUR TIME YET RUN","duration":5,"multiplayer":false}}]}, createChannel(channelId, triggerArea3, channelBus))
script4.spawn(triggerArea4, {"enabled":true,"onEnter":[{"entityName":"clickArea9","actionId":"disable","values":{}},{"entityName":"tools","actionId":"print","values":{"message":"SNAP","duration":1,"multiplayer":false}}],"onLeave":[{"entityName":"tools","actionId":"print","values":{"message":"YOUR GONNA BE YETI FOOD RUN","duration":5,"multiplayer":false}}]}, createChannel(channelId, triggerArea4, channelBus))
script4.spawn(triggerArea5, {"enabled":true,"onEnter":[{"entityName":"clickArea9","actionId":"disable","values":{}},{"entityName":"tools","actionId":"print","values":{"message":"CRUNCH","duration":1,"multiplayer":false}}],"onLeave":[{"entityName":"tools","actionId":"print","values":{"message":"GET OUTTA THERE","duration":5,"multiplayer":false}}]}, createChannel(channelId, triggerArea5, channelBus))
script2.spawn(clickArea12, {"enabled":true,"onClick":[{"entityName":"scoreboard","actionId":"increase","values":{}},{"entityName":"clickArea12","actionId":"disable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"present3","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea12","x":0,"y":0,"z":0,"speed":10,"onComplete":[]}}]}}]}, createChannel(channelId, clickArea12, channelBus))
script2.spawn(clickArea13, {"enabled":true,"onClick":[{"entityName":"tools","actionId":"print","values":{"message":"\"Oh hey, you're an adrenaline junky too.\"","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":2,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"Unfortunately for us the end is near.\"","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":5,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"You can go first I'll watch.\"","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"rotate","values":{"target":"penguin9","x":0,"y":150,"z":0,"speed":10,"onComplete":[]}}]}}]}}]}, createChannel(channelId, clickArea13, channelBus))
script2.spawn(clickArea14, {"enabled":true,"onClick":[{"entityName":"tools","actionId":"scale","values":{"target":"unlitTorch","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"print","values":{"message":"You pick up the unlit torch.","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"scale","values":{"target":"clickArea14","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"clickArea15","actionId":"enable","values":{}}]}}]}}]}, createChannel(channelId, clickArea14, channelBus))
script2.spawn(clickArea15, {"enabled":false,"onClick":[{"entityName":"tools","actionId":"print","values":{"message":"You lit your torch","duration":5,"multiplayer":false}},{"entityName":"clickArea16","actionId":"enable","values":{}}]}, createChannel(channelId, clickArea15, channelBus))
script2.spawn(clickArea16, {"enabled":false,"onClick":[{"entityName":"tools","actionId":"scale","values":{"target":"iceboulder2","x":0,"y":0,"z":0,"speed":2,"onComplete":[{"entityName":"clickArea17","actionId":"enable","values":{}}]}},{"entityName":"tools","actionId":"scale","values":{"target":"clickArea16","x":0,"y":0,"z":0,"speed":10,"onComplete":[]}}]}, createChannel(channelId, clickArea16, channelBus))
script2.spawn(clickArea17, {"enabled":false,"onClick":[{"entityName":"scoreboard","actionId":"increase","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"present4","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea17","x":0,"y":0,"z":0,"speed":10,"onComplete":[]}}]}}]}, createChannel(channelId, clickArea17, channelBus))
script4.spawn(triggerArea6, {"enabled":true,"onEnter":[{"entityName":"tools","actionId":"print","values":{"message":"\"Psst hey kid, wait here for a moment.\"","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":5,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"I know what you seek\"","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":5,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"Answer me this riddle and what you desire will be waiting for you on this stump\"","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":5,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"What's black, white and red all over?\"","duration":5,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":5,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"Don't return until you've found it.\"","duration":4,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":2,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"The all seeing Treeman has spoken\"","duration":4,"multiplayer":false}},{"entityName":"tools","actionId":"delay","values":{"timeout":3,"onTimeout":[{"entityName":"tools","actionId":"print","values":{"message":"\"Now go.\"","duration":5,"multiplayer":false}}]}}]}}]}}]}}]}}]}}],"onLeave":[{"entityName":"triggerArea6","actionId":"disable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"triggerArea6","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"clickArea19","actionId":"enable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"clickArea18","x":0,"y":0,"z":0,"speed":10,"onComplete":[]}}]}}]}, createChannel(channelId, triggerArea6, channelBus))
script2.spawn(clickArea18, {"enabled":true,"onClick":[{"entityName":"tools","actionId":"print","values":{"message":"ZZZzzz","duration":5,"multiplayer":false}}]}, createChannel(channelId, clickArea18, channelBus))
script2.spawn(clickArea19, {"enabled":false,"onClick":[{"entityName":"tools","actionId":"scale","values":{"target":"newspaper","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"print","values":{"message":"You take the newspaper.","duration":5,"multiplayer":false}},{"entityName":"clickArea20","actionId":"enable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"present5","x":1,"y":1,"z":1,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea20","x":1,"y":1,"z":1,"speed":10,"onComplete":[{"entityName":"tools","actionId":"move","values":{"target":"present5","x":0,"y":0.6,"z":0,"speed":10,"relative":true,"onComplete":[{"entityName":"tools","actionId":"move","values":{"target":"clickArea20","x":0,"y":0.5,"z":0,"speed":10,"relative":true,"onComplete":[]}}]}}]}}]}}]}}]}, createChannel(channelId, clickArea19, channelBus))
script2.spawn(clickArea20, {"enabled":false,"onClick":[{"entityName":"scoreboard","actionId":"increase","values":{}},{"entityName":"clickArea20","actionId":"disable","values":{}},{"entityName":"tools","actionId":"scale","values":{"target":"present5","x":0,"y":0,"z":0,"speed":10,"onComplete":[{"entityName":"tools","actionId":"scale","values":{"target":"clickArea20","x":0,"y":0,"z":0,"speed":10,"onComplete":[]}}]}}]}, createChannel(channelId, clickArea20, channelBus))